package dataBase;

import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by zengyouzu on 2019/1/31.
 * 数据库工具类
 */
public class DatabaseUtil {

    //测试连接是否成功
    @Test
    public static void testDBConnect() {
        connectToDB();
    }

    private static String mySQLDriver = "com.mysql.jdbc.Driver";
    private static String oracleDriver = "oracle.jdbc.driver.OracleDriver";

    private static String AccountUrl = "jdbc:oracle:thin:@xxx.xxx.xxx.xxx:xxxx/xxxx";
    private static String AccountUserName = "xxx";
    private static String AccountPassWord = "xxx";

    //测试环境mysql数据库erp_st库
    private static String url = "jdbc:mysql://rm-bp1y969moaa0s3dv1do.mysql.rds.aliyuncs.com:3306/erp_st";
    private static String uesrname = "erp";
    private static String password = "erp";

    static {
        try {
            Class.forName(mySQLDriver);
//            Class.forName(oracleDriver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //测试数据库连接
    public static void connectToDB() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, uesrname, password);
            if (connection != null) {
                System.out.println("连接成功");
                connection.close();
                if (connection.isClosed()) {
                    System.out.println("关闭成功");
                } else {
                    System.out.println("关闭失败");
                }
            } else {
                System.out.println("连接失败");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
