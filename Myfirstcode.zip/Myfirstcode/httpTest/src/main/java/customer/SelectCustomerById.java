package customer;

import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * id查询客户
 */
public class SelectCustomerById {
    @Test
    public void test() {
        String id = "51566";
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/crm/customer/" + id;
//        String url = "https://app.maxima-cars.com/api/v1/webapp/crm/customer/" + id;
        String token = "4add578600ef8152e9e52ac566b8be6c";
        HttpMethod.get(url, token);
    }
}

