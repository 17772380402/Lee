package customer;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * 转移客户给他人
 */
public class TransferCustomer {
    @Test
    public void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/crm/customer/transfer";
//        String url = "https://app.maxima-cars.com/api/v1/webapp/crm/customer/transfer";
        String token = "37cfa30a5a025246babc1e06854c6a06";
        String custId = "324132143214247";
        int receiveId = 152;
        JSONObject request = new JSONObject("{" +
                "  \"custIds\": [\"" + custId + "\"" +
                "  ]," +
                "  \"receiveId\": " + receiveId + "" +
                "}");
        HttpMethod.post(url, token, request);
    }
}
