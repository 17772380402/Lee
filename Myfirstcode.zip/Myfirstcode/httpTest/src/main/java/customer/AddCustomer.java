package customer;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

/**
 * 新增客户
 */
public class AddCustomer {
    @Test
    public void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/crm/customer";
//        String url = "https://app.maxima-cars.com/api/v1/webapp/crm/customer";
        String token = "22ec1b84af73309efe6f11c2ac9a3b4a";
        JSONObject request = new JSONObject("{" +
                "  \"addr\": \"" + DataUtil.addr + "\"," +
                "  \"age\": " + null + "," +
                "  \"city\": " + null + "," +
                "  \"contact\": " + null + "," +
                "  \"contactRelation\": " + null + "," +
                "  \"contactTelephone\": " + null + "," +
                "  \"criminalRecord\": " + null + "," +
                "  \"custLevel\": \"" + DataUtil.custLevel + "\"," +
                "  \"custName\": \"" + DataUtil.name + "\"," +
                "  \"didiAccount\": " + null + "," +
                "  \"drivingAge\": " + null + "," +
                "  \"gender\": " + null + "," +
                "  \"idNo\": \"" + DataUtil.idNo + "\"," +
                "  \"interviewJob\": " + null + "," +
                "  \"introductionMobile\": " + null + "," +
                "  \"introductionName\": " + null + "," +
                "  \"introductionStatus\": " + null + "," +
                "  \"majorTrafficAcc\": " + null + "," +
                "  \"mobile\": \"" + DataUtil.mobile + "\"," +
                "  \"nativePlace\": " + null + "," +
                "  \"networkCarLic\": " + null + "," +
                "  \"remark\": " + null + "," +
                "  \"secretNumber\": " + null + "," +
                "  \"source\": \"" + DataUtil.source + "\"," +
                "  \"uniqueMark\": " + null + "," +
                "}");
        HttpMethod.post(url, token, request);
    }
}
