package out_in_depot;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;
import java.util.HashMap;

    /**
     * 查询出入库列表
     */

public class select_Out_in_depot {
    @Test
    public static void test1() {
      String url = "https://st-app.maxima-cars.com/api/v1/wabapp/depot/list/";
      String token = "4add578600ef8152e9e52ac566b8be6c";
      String custId = "51566";//客户id
      String Id = "2351";//出入库id
      String plate= "渝A000001";

        JSONObject request = new JSONObject
              ("{" +
              "\"custId\":\"" + custId + "\"," +
              "\"Id\":\"" + Id + "\"," +
              "\"plate\":\"" + plate + "\"," +
              "}");
      HttpMethod.post(url, token, request);
  }
};





