package energy;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * 开始充电
 */
public class StartCharge {
    @Test
    public static void test() {
        String url = "https://energy.maxima-cars.com/api/v1/energy/test/start";
//        String url = "http://testapi.maxima-cars.com/api/v1/energy/test/start";
//        String token = "13120558849!@ST$%DFGRY$%dfgjdkree1600568010192";
        String id = "1";//桩id
        String userId = "18";//用户id

        JSONObject request = new JSONObject("{" +
                "\"id\":\"" + id + "\"," +
                "\"userId\":\"" + userId + "\"," +
                "}");
        HttpMethod.post(url, "", request);
    }
}
