package energy;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * 变更充电桩状态
 */
public class NotifyStationStatus {
    @Test
    public static void test() {
        String url = "https://energy.maxima-cars.com/api/v1/energy/test/notification_stationStatus";
        String token = "13120558849!@ST$%DFGRY$%dfgjdkree1600568010192";
        String operatorId = "395815801";//特来电
//        String operatorId = "312374490";//鼎充
        String connectorId = "3101010047201";
        int status = 1;//1:空闲 2:已插枪 3:充电中 4:已预约 255:故障

        JSONObject request = new JSONObject("{" +
                "\"operatorId\":\"" + operatorId + "\"," +
                "\"connectorId\":\"" + connectorId + "\"," +
                "\"status\":\"" + status + "\"," +
                "}");
        HttpMethod.post(url, token, request);
    }
}
