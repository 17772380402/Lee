package energy;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * 订单结算
 */
public class NotifyChargeOrderInfo {
    @Test
    public static void test() {
        String url = "https://energy.maxima-cars.com/api/v1/energy/test/notification_charge_order_info";
//        String token = "13120558849!@ST$%DFGRY$%dfgjdkree1600568010192";
        String orderNo = "MA1FWA5N4C20200927095119859";
        String connectorId = "130043138741";
        String endTime = "2020-09-27 12:30:00";
        float totalPower = 10.000f;//充电度数（度）
        float totalEletcMoney = 0.567f;//电费
        float totalSeviceMoney = 0.800f;//服务费
        float totalMoney = 0.000f;//总费用


        JSONObject request = new JSONObject("{" +
                "  \"StartChargeSeq\":\"" + orderNo + "\"," +
                "  \"ConnectorID\":\"" + connectorId + "\"," +
//                "  \"StartTime\":\"" + startTime + "\"," +
                "  \"EndTime\":\"" + endTime + "\"," +
                "  \"TotalPower\":\"" + totalPower + "\"," +
//                "  \"TotalElecMoney\":\"" + totalEletcMoney + "\"," +
//                "  \"TotalSeviceMoney\":\"" + totalSeviceMoney + "\"," +
                "  \"TotalMoney\":\"" + totalMoney + "\"," +
                "}");
        HttpMethod.post(url, "", request);
    }
}
