package utils;

import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.RandomUtil;
import com.github.javafaker.Faker;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

public class DataUtil {
    private static Faker faker = new Faker(new Locale("zh_CN"));
    public static String name = new String(faker.name().fullName());
    public static String mobile = new String(faker.phoneNumber().cellPhone());
    public static String custLevel = getCustLevel();
    public static String source = getSource();
    public static String idNo = getIdNo();
    public static String addr = new String(faker.address().streetAddress());

    public static String vinCode = getVinCode();
    public static String licensePlate = getLicensePlate();
    public static String engineNo = RandomUtil.randomNumbers(8);
    public static int vehicleModel = getVehicleModel();
    public static String color = getColor();
    public static String registerDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").format(
            Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).minusDays(365).withHour(0).withMinute(0).withSecond(0).toInstant(ZoneOffset.ofHours(8))));
    public static String validDate = new SimpleDateFormat("yyyy-MM-dd").format(
            Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).plusDays(365).toInstant(ZoneOffset.ofHours(8))));
    public static String useType = getUseType();
    public static String vehicleType = getVehicleType();

    public static String insuaranceCompany = getInsuranceCompany();
    public static String insuranceArea = insuaranceCompany + "支行";
    public static String insuranceIdentity = getInsuranceIdentity();
    public static String insuranceStartDate = new SimpleDateFormat("yyyy-MM-dd").format(
            Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).toInstant(ZoneOffset.ofHours(8))));
    public static String insuranceEndDate = new SimpleDateFormat("yyyy-MM-dd").format(
            Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).plusDays(364).toInstant(ZoneOffset.ofHours(8))));
    public static Integer insuranceCost = new Integer(faker.number().numberBetween(0, 10000) * 100);

    public static String breakReason = getBreakReason();

    public static String activityStartDate = getActivityStartDate();
    public static String activityEndDate = getActivityEndDate();
    public static String inspectDate = new SimpleDateFormat("yyyy-MM-dd").format(
            Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).plusDays(365).toInstant(ZoneOffset.ofHours(8))));

    @Test
    public void test() {
//        System.out.println("name" + ":" + name);
//        System.out.println(mobile);
//        System.out.println(custLevel);
//        System.out.println(source);
//        System.out.println(idNo);
//        System.out.println(addr);
//        System.out.println("vinCode" + ":" + vinCode);
//        System.out.println("licensePlate" + ":" + licensePlate);
//        System.out.println("engineNo" + ":" + engineNo);
//        System.out.println("vehicleModel" + ":" + vehicleModel);
//        System.out.println("color" + ":" + color);
//        System.out.println("registerDate" + ":" + registerDate);
//        System.out.println("validDate" + ":" + validDate);
//        System.out.println("useType" + ":" + useType);
//        System.out.println("vehicleType" + ":" + vehicleType);
//        System.out.println("insuaranceCompany" + ":" + insuaranceCompany);
//        System.out.println("insuranceArea" + ":" + insuranceArea);
//        System.out.println("insuranceIdentity" + ":" + insuranceIdentity);
//        System.out.println("insuranceStartDate" + ":" + insuranceStartDate);
//        System.out.println("insuranceEndDate" + ":" + insuranceEndDate);
//        System.out.println("insuranceCost" + ":" + insuranceCost);
    }

    /**
     * ========================================公共方法========================================
     **/

    //根据传入文件路径读取文件(文本格式)
    public static List<String> getFile(String filePath) {
        String path = Thread.currentThread().getContextClassLoader().getResource(filePath).getPath();
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        //按行读取文件存入list
        List<String> list = new ArrayList<>();
        String str = null;
        try {
            while ((str = bufferedReader.readLine()) != null) {
                if (str.trim().length() > 0) {
                    list.add(str);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    //生成随机字符串(仅数字)
    public static String getRandomNo() {
        String str = RandomUtil.randomNumbers(12);
        return str;
    }

    /**
     ========================================个人相关========================================
     **/

    /**
     * 客户等级 11501: A类, 11502: B类, 11503: C类, 11504: D类, 11505: E类, 11506: F类
     */
    private static String getCustLevel() {
        String[] custLevel = {"11501", "11502", "11503", "11504", "11505", "11506"};
        String randomCustLevel = custLevel[new Random().nextInt(custLevel.length - 1)];
        return randomCustLevel;
    }


    /**
     * 客户来源
     */
    private static String getSource() {
        String[] source = {"58下载", "58投递", "在职转介绍", "抖音", "渠道商介绍",
                "代管理拉新", "小桔有车", "老司机回归", "自然来访", "司机群", "400来电",
                "朋友介绍", "司机群司机介绍", "地推司机介绍", "行业介绍", "线上线索介绍"};
        String randomSource = source[new Random().nextInt(source.length - 1)];
        return randomSource;
    }

    /**
     * 生成有效身份证号码
     */
    private static String getIdNo() {
        StringBuilder identityNo = new StringBuilder();
        String str = null;
        List<String> list = null;

        //省、自治区、直辖市代码+地级市、盟、自治州代码+县、县级市、区代码 身份证前6位
        list = getFile("documents//id_code.txt");
        //随机读取list中数据
        int index = new Random().nextInt(list.size());
        str = list.get(index);
        identityNo.append(str);

        //随机生成出生年月 身份证第7-14位
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date date = Date.from(LocalDateTime.now().minusYears((int) (20 + Math.random() * (100 - 20 + 1))).toInstant(ZoneOffset.ofHours(8)));
        str = sdf.format(date);
        identityNo.append(str);

        //随机生成顺序号 身份证第15-17位(随机性别)
        str = String.format("%03d", (int) (0 + Math.random() * (999 - 0 + 1)));
        identityNo.append(str);

        //随机生成校验码 身份证第18位(包含算法逻辑)
        StringBuilder sb = new StringBuilder(identityNo);
        int[] a = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};
        char[] b = {'1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'};
        int[] c = new int[17];
        int result = 0;
        for (int i = 0; i < c.length; i++) {
            c[i] = Integer.parseInt(String.valueOf(sb.charAt(i)));
        }
        for (int i = 0; i < c.length; i++) {
            result += a[i] * c[i];
        }
        str = String.valueOf(b[result % 11]);
        identityNo.append(str);

        return String.valueOf(identityNo);
    }

    /**
     ========================================车辆相关========================================
     **/

    /**
     * 生成车辆vin码
     */
    private static String getVinCode() {
        StringBuilder sb = new StringBuilder();
        int[] a = {8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2};
        String[] b = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        Dict dict = Dict.create().set("A", 1).set("B", 2).set("C", 3).set("D", 4).set("E", 5).set("F", 6).set("G", 7).set("H", 8).set("J", 1).set("K", 2).set("L", 3).
                set("M", 4).set("N", 5).set("P", 7).set("R", 9).set("S", 2).set("T", 3).set("U", 4).set("V", 5).set("W", 6).set("X", 7).set("Y", 8).set("Z", 9).
                set("0", 0).set("1", 1).set("2", 2).set("3", 3).set("4", 4).set("5", 5).set("6", 6).set("7", 7).set("8", 8).set("9", 9);
        String vin = null;
        int num = 0;
        List<String> vinList = new ArrayList();
        for (int i = 0; i < 17; i++) {
            vin = b[new Random().nextInt(b.length - 1)];
            vinList.add(vin);
            num += dict.getInt(vinList.get(i)) * a[i];
        }
        int vinSum = num % 11;
        if (vinSum == 10) {
            vinList.set(8, "X");
        } else {
            vinList.set(8, String.valueOf(vinSum));
        }
        for (String s : vinList) {
            sb.append(s);
        }
        return String.valueOf(sb);
    }

    /**
     * 生成车牌
     */
    private static String getLicensePlate() {
        StringBuilder sb = new StringBuilder();
        String str = null;
        List<String> list = null;
        list = getFile("documents/license_plate_initial.txt");
        //随机读取list中数据
        int index = new Random().nextInt(list.size());
        str = list.get(index);
        sb.append(str);
        sb.append(RandomUtil.randomNumbers(5));
        return String.valueOf(sb);
    }

    /**
     * 生成车型
     */
    private static int getVehicleModel() {
        String str = null;
        List<String> list = null;
        list = getFile("documents/vehicle_model.txt");
        //随机读取list中数据
        int index = new Random().nextInt(list.size());
        str = list.get(index);
        return Integer.parseInt(str);
    }

    /**
     * 车辆颜色
     */
    private static String getColor() {
        String[] color = {"白色", "黑色", "银灰色", "深灰色", "红色", "蓝色",
                "香槟色", "棕色", "紫色", "绿色", "粉色", "黄色", "其他"};
        String randomColor = color[new Random().nextInt(color.length - 1)];
        return randomColor;
    }

    /**
     * 使用性质 10601:非营运, 10602:营运， 10603:预约出租客运, 10604:营转非, 10605:非转营, 10606:租赁
     */
    private static String getUseType() {
        String[] useType = {"10601", "10602", "10603", "10604", "10605", "10606"};
        String randomUseType = useType[new Random().nextInt(useType.length - 1)];
        return randomUseType;
    }

    /**
     * 车辆类型 13403:小型汽车, 13404:大型汽车， 13405:小型新能源汽车, 13406:大型新能源汽车
     */
    private static String getVehicleType() {
        String[] vehicleType = {"13403", "13404", "13405", "13406"};
        String randomVehicleType = vehicleType[new Random().nextInt(vehicleType.length - 1)];
        return randomVehicleType;
    }

    /**
     * ========================================保险相关========================================
     **/

    /**
     * 保险公司
     */
    private static String getInsuranceCompany() {
        String[] insuranceCompany = {"深圳平安", "宁波平安", "厦门人保", "杭州人保", "广州人保", "东莞人保",
                "深圳中银", "广州中银", "厦门阳光", "重庆锦泰", "永诚保险", "长沙中华联合", "苏州太平洋", "深圳太平洋",
                "深圳人保", "重庆人保", "永安", "厦门平安", "佛山平安", "武汉人保", "上海太平", "深圳太平", "测试保险"};
        String randomInsuranceCompany = insuranceCompany[new Random().nextInt(insuranceCompany.length - 1)];
        return randomInsuranceCompany;
    }

    /**
     * 投保人员 13701:司机， 13702:公司
     */
    private static String getInsuranceIdentity() {
        String[] insuranceIdentity = {"13701", "13702"};
        String randomInsuranceIdentity = insuranceIdentity[new Random().nextInt(insuranceIdentity.length - 1)];
        return randomInsuranceIdentity;
    }

    /**
     * ========================================合同相关========================================
     **/

    /**
     * 客户来源
     */
    private static String getBreakReason() {
        String[] breakReason = {"家庭原因", "收入原因", "平台原因", "身体原因", "方案原因",
                "抓车解约", "车辆原因", "运营原因", "其他原因", "劝退原因"};
        String randomBreakReason = breakReason[new Random().nextInt(breakReason.length - 1)];
        return randomBreakReason;
    }

    /**
     * ========================================优惠券相关========================================
     **/

    /**
     * 活动开始时间
     */
    private static String getActivityStartDate() {
        String activityStartDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").format(
                Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).withHour(0).withMinute(0).withSecond(0).toInstant(ZoneOffset.ofHours(8))));
        return activityStartDate;
    }

    /**
     * 活动结束时间
     */
    private static String getActivityEndDate() {
        String activityEndDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").format(
                Date.from(LocalDateTime.now(ZoneOffset.ofHours(8)).plusDays(10).withHour(0).withMinute(0).withSecond(0).toInstant(ZoneOffset.ofHours(8))));
        return activityEndDate;
    }
}
