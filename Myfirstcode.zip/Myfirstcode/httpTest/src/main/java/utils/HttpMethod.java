package utils;

import cn.hutool.core.lang.Console;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.*;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;

import java.util.HashMap;

public class HttpMethod {
    public static void post(String url, String token, JSONObject parameter) {
        HttpRequest request = HttpRequest.post(url)
                .header("token", token)
                .body(JSONUtil.toJsonStr(parameter))
                .timeout(5000);
        Console.log("请求参数:" + parameter);

        HttpResponse response = request.execute();
        if (response.isOk()) {
            Console.log("响应结果:" + response.body());
        } else {
            Console.log("post请求失败!" + response.getStatus() + response.body());
        }
    }

    public static void post(String url, String token, HashMap<String, Object> parameter) {
        HttpRequest request = null;
        if (parameter != null) {
            request = HttpRequest.post(url)
                    .header("token", token)
                    .body(String.valueOf(parameter))
                    .timeout(5000);
            Console.log("请求参数:" + parameter);
        } else {
            request = HttpRequest.post(url)
                    .header("token", token)
                    .timeout(5000);
        }
        HttpResponse response = request.execute();
        if (response.isOk()) {
            Console.log("响应结果:" + response.body());
        } else {
            Console.log("post请求失败!" + response.getStatus() + response.body());
        }
    }

    public static void get(String url, String token) {
        HttpRequest request = HttpRequest.get(url)
                .header("token", token)
                .timeout(5000);

        HttpResponse response = request.execute();
        if (response.isOk()) {
            Console.log("响应结果:" + response.body());
        } else {
            Console.log("get请求失败!" + response.getStatus());
        }
    }

    public static JSONObject delete(String url, String header, String token) {
        HttpRequest httpRequest = HttpUtil.createRequest(Method.DELETE, url).timeout(5000);
        if (StrUtil.isNotBlank(header) && StrUtil.isNotBlank(token)) {
            httpRequest.header(header, token);
        }
        HttpResponse response = httpRequest.execute();
        if (response.isOk()) {
            System.out.println("响应结果:" + response.body());
            return new JSONObject(response.body());
        }
        System.out.println("delete请求失败!" + response.getStatus());
        return null;
    }

    public static JSONObject put(String url, String header, String token, JSONObject parameter) {
        HttpRequest httpRequest = HttpUtil.createRequest(Method.PUT, url).body(JSONUtil.toJsonStr(parameter)).timeout(5000);
        if (StrUtil.isNotBlank(header) && StrUtil.isNotBlank(token)) {
            httpRequest.header(header, token);
        }
        HttpResponse response = httpRequest.execute();
        System.out.println("请求参数:" + parameter);
        if (response.isOk()) {
            System.out.println("响应结果:" + response.body());
            return new JSONObject(response.body());
        }
        System.out.println("put请求失败!" + response.getStatus());
        return null;
    }
}
