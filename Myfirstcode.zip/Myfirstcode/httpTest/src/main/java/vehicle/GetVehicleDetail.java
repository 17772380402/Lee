package vehicle;

import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * 查询车辆信息详情
 */
public class GetVehicleDetail {
    @Test
    public static void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/asset/vehicle";
        String token = "4add578600ef8152e9e52ac566b8be6c";
        int vehicleId = 26185;
        url = url + "/" + vehicleId;
        HttpMethod.get(url, token);
    }
}
