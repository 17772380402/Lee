package vehicle;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

/**
 * 新增车辆
 */
public class AddVehicle {
    @Test
    public static void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/asset/vehicle";
        String token = "c55a01847b3bf85aeeac0fc270c91bb6";
        String modelId = "27540";//测试环境专用方案车型(领雅2008 1.4T)
        String type = "13403";//测试环境专用方案车辆类型(小型汽车)

        JSONObject request = new JSONObject("{" +
                "  \"certDate\": \"" + DataUtil.registerDate + "\"," +
                "  \"color\": \"" + DataUtil.color + "\"," +
                "  \"engineNo\": \"" + DataUtil.engineNo + "\"," +
//                "  \"modelId\": " + DataUtil.vehicleModel + "," +
                "  \"modelId\": " + modelId + "," +
                "  \"owner\": \"" + DataUtil.name + "\"," +
                "  \"partnerId\": 0," +
                "  \"partnerType\": 0," +
                "  \"plate\": \"" + DataUtil.licensePlate + "\"," +
                "  \"registerDate\": \"" + DataUtil.registerDate + "\"," +
                "  \"remark\": " + null + "," +
                "  \"scrapInfo\": " + null + "," +
                "  \"transportCert\": true," +
                "  \"type\": \"" + type + "\"," +
                "  \"useType\": \"" + DataUtil.useType + "\"," +
                "  \"validDate\": \"" + DataUtil.validDate + "\"," +
                "  \"vinCode\": \"" + DataUtil.vinCode + "\"," +
                "}");
        HttpMethod.post(url, token, request);
    }
}
