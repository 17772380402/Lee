package vehicle;

import cn.hutool.core.lang.Console;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONUtil;
import org.testng.annotations.Test;
import utils.HttpMethod;

import java.util.HashMap;

public class Departure {
    @Test
    public static void test() {
        String url = "https://app.maxima-cars.com/api/v1/webapp/asset/vehicle/departure";
        String token = "37cfa30a5a025246babc1e06854c6a06";
        int vehicleId = 26170;
        
        HashMap<String, Object> paramMap = new HashMap<>();
        paramMap.put("ids", vehicleId);
        HttpMethod.post(url, token, paramMap);
    }
}
