package intention.order;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

public class CreateOrder {
    @Test
    public static void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/intentionOrder/create";
        String token = "22ec1b84af73309efe6f11c2ac9a3b4a";
        String drip = "13801";
        String introduceMobile = "18017751324";
        String introduceName = "李李李";

        JSONObject request = new JSONObject("{" +
                "  \"cityId\": 0," +
                "  \"contact\": \"" + DataUtil.name + "\"," +
                "  \"contactTelephone\": \"" + DataUtil.mobile + "\"," +
                "  \"custName\": \"" + DataUtil.name + "\"," +
                "  \"drip\": \"" + drip + "\"," +
                "  \"hasResidentLiscence\": true," +
                "  \"idNo\": \"" + DataUtil.idNo + "\"," +
                "  \"introduceMobile\": " + introduceMobile + "," +
                "  \"introduceName\": " + introduceName + "," +
                "  \"mobile\": \"" + DataUtil.mobile + "\"," +
                "  \"networkCarLic\": false," +
                "  \"productId\": 609," +
                "  \"productType\": 10," +
                "  \"remarks\": " + null + "," +
                "  \"rentId\": 793," +
                "  \"source\": " + null + "," +
                "}");
        HttpMethod.post(url, token, request);
    }
}
