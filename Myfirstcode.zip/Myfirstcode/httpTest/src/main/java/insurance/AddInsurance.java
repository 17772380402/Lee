package insurance;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

/**
 * 新增保单
 */
public class AddInsurance {
    @Test
    public static void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/insurance";
        String token = "7954399f23bee7f3438a36785cfc6a30";

        int vehicleId = 26170;
        String insuranceType1 = "13601";
        String insuranceType2 = "13602";
        String insuranceType3 = "13603";
















        JSONObject request1 = new JSONObject("{" +
                "  \"company\": \"" + DataUtil.insuaranceCompany + "\"," +
                "  \"cost\": " + DataUtil.insuranceCost + "," +
                "  \"endDate\": \"" + DataUtil.insuranceEndDate + "\"," +
                "  \"insuranceArea\": \"" + DataUtil.insuranceArea + "\"," +
                "  \"insuranceIdentity\": \"" + DataUtil.insuranceIdentity + "\"," +
                "  \"insuranceNo\": \"" + DataUtil.getRandomNo() + "\"," +
                "  \"insuranceType\": \"" + insuranceType1 + "\"," +
                "  \"remark\": \"string\"," +
                "  \"seatInsu\": true," +
                "  \"startDate\": \"" + DataUtil.insuranceStartDate + "\"," +
                "  \"vehicleId\": " + vehicleId + "," +
                "}");
        JSONObject request2 = new JSONObject("{" +
                "  \"company\": \"" + DataUtil.insuaranceCompany + "\"," +
                "  \"cost\": " + DataUtil.insuranceCost + "," +
                "  \"endDate\": \"" + DataUtil.insuranceEndDate + "\"," +
                "  \"insuranceArea\": \"" + DataUtil.insuranceArea + "\"," +
                "  \"insuranceIdentity\": \"" + DataUtil.insuranceIdentity + "\"," +
                "  \"insuranceNo\": \"" + DataUtil.getRandomNo() + "\"," +
                "  \"insuranceType\": \"" + insuranceType2 + "\"," +
                "  \"remark\": \"string\"," +
                "  \"seatInsu\": true," +
                "  \"startDate\": \"" + DataUtil.insuranceStartDate + "\"," +
                "  \"vehicleId\": " + vehicleId + "," +
                "}");
        HttpMethod.post(url, token, request1);
        HttpMethod.post(url, token, request2);
    }
}
