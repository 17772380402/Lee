import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;

public class HttpTest {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/oa/notify";//测试环境
//    String url = "https://app.maxima-cars.com/api/v1/webapp/oa/notify";//生产环境
    JSONObject request = new JSONObject("{" +
            "  \"requestId\": 12044," +
            "  \"flowId\": 62," +
            "  \"auditStatus\": 2," +
            "  \"remark\": \"null\"" +
            "}");

    @Test
    public void test() {
        HttpMethod.post(url, "", request);
    }
}

