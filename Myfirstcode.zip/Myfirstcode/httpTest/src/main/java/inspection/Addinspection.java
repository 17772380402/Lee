package inspection;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

import java.util.HashMap;
import java.util.Map;

public class Addinspection {
    @Test
    public void test(){
        String url="https://st-tsp.maxima-cars.com/api/v1/webapp/asset/inspect/save";
        String token="4add578600ef8152e9e52ac566b8be6c";
        String costHolder= "14001";
        String fee="10000";
        String inspectOffice="上海";
        String qualifiedDesc="合格";
        String transactorType="13901";
        String type="1";
        String vehicleId= "25172";
        String plate= "渝A000001";


//
//        Map<String, String> params = new HashMap<>();
//        params.put("costHolder",costHolder);
////        params.put("costHolder",costHolder);
//        JSONObject object = new JSONObject(params);
//System.out.println(object);





        JSONObject request = new JSONObject ("{" +
                "  \"costHolder\": \"" + costHolder + "\"," +
                "  \"fee\": " + fee + "," +
                "  \"inspectDate\": " + DataUtil.inspectDate + "," +
                "  \"inspectOffice\": " + inspectOffice + "," +
                "  \"plate\": \"" + plate + "\"," +
                "  \"qualifiedDesc\": " + qualifiedDesc + "," +
                "  \"transactorType\": " + transactorType + "," +
                "  \"type\": " + type + "," +
                "  \"validDate\": " + DataUtil.validDate + "," +
                "  \"vehicleId\": " + vehicleId + "," +
                "}");
        System.out.println(request);


    }
}
