package contract.operate;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;

/**
 * 合同审批
 */
public class AuditContract {
    @Test
    public static void test(){
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/contract/operate/audit";
        String token = "c885d3e1b5c6f007bb417175e7c2ac1d";

        JSONObject request = new JSONObject("{" +
                "  \"auditStatus\": \"string\"," +
                "  \"corpId\": 0," +
                "  \"corpIds\": [" +
                "    0" +
                "  ]," +
                "  \"creatorId\": 0," +
                "  \"endDate\": \"2020-09-01T03:21:33.746Z\"," +
                "  \"export\": true," +
//                "  \"gmtCreate\": \"2020-09-01T03:21:33.746Z\"," +
//                "  \"gmtModify\": \"2020-09-01T03:21:33.746Z\"," +
                "  \"id\": 0," +
                "  \"keyword\": \"string\"," +
                "  \"offset\": 0," +
                "  \"operatorUser\": {" +
                "    \"corpId\": 0," +
                "    \"operatorUserId\": 0," +
                "    \"operatorUserName\": \"string\"" +
                "  }," +
//                "  \"pageIndex\": 0," +
//                "  \"pageSize\": 0," +
//                "  \"remark\": \"string\"," +
//                "  \"startDate\": \"2020-09-01T03:21:33.746Z\"," +
//                "  \"tenantId\": 0" +
                "}");
    }
}
