package contract.operate;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

/**
 * 合同违约退车
 */
public class BreakContract {
    @Test
    public static void test(){
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/contract/operate/breakReturn";
        String token = "c885d3e1b5c6f007bb417175e7c2ac1d";

        int id = 70447;
        JSONObject request = new JSONObject("{" +
                "  \"attachments\": [" +
                null + "," +
                "  ]," +
                "  \"id\": " + id + "," +
                "  \"reason\": \"" + DataUtil.breakReason + "\"," +
                "}");
        HttpMethod.post(url, token, request);
    }
}
