package contract.operate;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.HttpMethod;

/**
 * 合同延期
 */
public class ExtendContract {
    @Test
    public static void test() {
        String url = "https://st-app.maxima-cars.com/api/v1/webapp/contract/operate/contractExtend";
        String token = "c885d3e1b5c6f007bb417175e7c2ac1d";

        int extendDays = 10;
        int extendFees = extendDays * 150;
        int id = 70447;
        String reason = "合同延期";
        JSONObject request = new JSONObject("{" +
                "  \"attachments\": [" +
                null + "," +
                "  ]," +
                "  \"extendDays\":" + extendDays + "," +
                "  \"extendFees\": " + extendFees + "," +
                "  \"id\": " + id + "," +
                "  \"reason\": \"" + reason + "\"," +
                "  \"remark\":  " + null + "," +
                "}");
        HttpMethod.post(url, token, request);
    }
}
