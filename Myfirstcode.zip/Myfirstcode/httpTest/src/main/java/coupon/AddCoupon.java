package coupon;

import cn.hutool.json.JSONObject;
import org.testng.annotations.Test;
import utils.DataUtil;
import utils.HttpMethod;

import java.util.Random;
import java.util.UUID;

/**
 * 新增优惠券活动
 */
public class AddCoupon {
    static Random random;

    public static int random(int i) {
        random = new Random();
        return random.nextInt(i) % (i - 1 + 1) + 1;
    }

    public static void addCoupon() {
        String url = "https://energy.maxima-cars.com/api/v1/admin/activity/add";
//        String url = "http://testapi.maxima-cars.com/api/v1/admin/activity/add";
        String token = "admin-token";
        String activityName = UUID.randomUUID().toString().replaceAll("-", "") + "优惠活动";
        int obtainWay = 1;//领取方式:1主动领取 2后台发放 3充值赠送
        int couponType = 1;//优惠类型:1现金券 2折扣券
        int couponAmount = 1000;//优惠金额:现金券时表示(xx/100)元，折扣券时表示(xx/100)折
        int threshold = 2;//使用门槛:1无门槛 2有门槛
        int useCouponTime = 1;//用券时间 1.领取后一定时间 2.固定时间
        int useTimeSlot = 1;//使用时段:1全时间段 2特定时间段

        JSONObject request = new JSONObject("{" +
                "\"activityName\":\"" + activityName + "\"," +
//                "\"obtainWay\":\"" + random(2) + "\"," +
                "\"obtainWay\":\"" + obtainWay + "\"," +
                "\"activityStart\":\"" + DataUtil.activityStartDate + "\"," +
                "\"activityEnd\":\"" + DataUtil.activityEndDate + "\"," +
                "\"couponType\":\"" + random(2) + "\"," +
//                "\"couponType\":\"" + couponType + "\"," +
                "\"couponAmount\":\"" + random(1000) + "\"," +
//                "\"couponAmount\":\"" + couponAmount + "\"," +
                "\"threshold\":\"" + random(2) + "\"," +
//                "\"threshold\":\"" + threshold + "\"," +
                "\"thresholdAmount\":\"" + random(1000) + "\"," +
                "\"totalAmount\":\"" + random(999999) + "\"," +
                "\"useCouponTime\":\"" + useCouponTime + "\"," +
                "\"useCouponDay\":\"" + random(30) + "\"," +
                "\"useCouponDate\":null," +
                "\"useTimeSlot\":\"" + useTimeSlot + "\"," +
                "\"timeSlotCount\":0," +
                "\"timeSlotTimeJson\":null," +
                "\"astrictAmount\":\"" + random(100) + "\"," +
                "\"useAstrict\":\"" + random(2) + "\"," +
                "\"operatorName\":\"admin\"" +
                "}");

        HttpMethod.post(url, token, request);
    }

    @Test
    public static void test() {
        for (int i = 0; i < 1; i++) {
            addCoupon();
        }
    }
}
