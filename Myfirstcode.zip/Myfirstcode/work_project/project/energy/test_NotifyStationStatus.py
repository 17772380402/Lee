from project.utils.HttpMethod import *
import pytest

'''
变更充电桩状态
'''


def test():
    url = "https://energy.maxima-cars.com/api/v1/energy/test/notification_stationStatus"
    operatorId = "395815801"  # 特来电 395815801，鼎充 312374490
    connectorId = "3101010047201"
    status = 1  # 1:空闲 2:已插枪 3:充电中 4:已预约 255:故障

    data = {
        'operatorId': operatorId,
        'connectorId': connectorId,
        'status': status
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_NotifyStationStatus.py'])
