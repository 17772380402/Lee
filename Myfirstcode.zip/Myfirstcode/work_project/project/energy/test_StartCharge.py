from project.utils.HttpMethod import *
import pytest

'''
开始充电(创建订单)
'''


def test():
    url = "https://energy-test.maxima-cars.com/api/v1/energy/test/start"
    id = "1"
    userId = "11"
    data = {
        'id': id,
        'userId': userId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_StartCharge.py'])
