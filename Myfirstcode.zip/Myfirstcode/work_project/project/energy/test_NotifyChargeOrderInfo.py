from project.utils.HttpMethod import *
import pytest

'''
订单结算
'''


def test():
    url = "https://energy-test.maxima-cars.com/api/v1/energy/test/notification_charge_order_info"
    orderNo = ""
    connectorId = ""
    endTime = "2020-09-27 12:30:00"
    totalPower = 10.000  # 充电度数
    totalMoney = 0.000  # 总费用

    data = {
        'StartChargeSeq': orderNo,
        'ConnectorID': connectorId,
        'EndTime': endTime,
        'TotalPower': totalPower,
        'TotalMoney': totalMoney
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_NotifyChargeOrderInfo.py'])
