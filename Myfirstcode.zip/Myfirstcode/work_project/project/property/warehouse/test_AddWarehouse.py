from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.warehouseData import *
import pytest

'''
新增中心仓
'''

centreName = "测试中心仓"
cityCode = "310100"
provinceCode = "310000"
centreStatus = 1  # 禁用:0, 启用:1


def test():
    url = "/api/v1/webapp/system/centre/warehouse/saveOrUpdate"
    data = {
        "address": addr,
        # "areaCode": areaCode,
        "areasName": areasName,
        "centreName": centreName,
        "centreStatus": centreStatus,
        "cityCode": cityCode,
        "cityName": "上海市",
        "corpId": 105338612,
        "provinceCode": provinceCode,
        "provinceName": "上海市",
        # "status": ""
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddWarehouse.py'])
