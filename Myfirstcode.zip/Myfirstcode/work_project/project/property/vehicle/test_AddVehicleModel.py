from project.utils.HttpMethod import *
import pytest

'''
新增车型
'''
brandName = ""
lineName = ""
modelName = ""
modelStatus = 1  # 启用:1, 禁用:0


def test():
    url = "/api/v1/webapp/asset/vehicle"
    data = {
        "brandName": brandName,
        "lineName": lineName,
        "modelName": modelName,
        "modelStatus": modelStatus
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddVehicleModel.py'])
