from project.utils.HttpMethod import *
from project.utils.data.vehicleData import *
import pytest

'''
查询新增合同可用车辆
'''

plate = "川Q40137"
modelId = 27540  # 测试环境专用方案车型(领雅2008 1.4T)
# type = 5


def test():
    url = "/api/v1/webapp/asset/vehicle/query"
    data = {
        "corpId": 99940212,
        "keyword": plate,
        "modelId": modelId,
        # "pageIndex": 1,
        # "pageSize": 10,
        # "type": type,
        "vehicleStatus": 10700,
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryVehicle.py'])
