from project.utils.HttpMethod import *
from project.utils.DataUtils import *
import pytest

'''
处置车辆
'''
vehicleId = "36793"
vehicleStatus = 10707  # 报废:10708, 过户:10707
custId = 1019806  # 处置方式为过户时必填


def test():
    url = "/api/v1/webapp/asset/vehicle/diposition"
    data = {
        "amount": 10000,
        "custId": custId,
        "dipositionDate": dateStr1,
        # "remark": "string",
        # "tags": [
        #     "string"
        # ],
        "vehicleId": vehicleId,
        "vehicleStatus": vehicleStatus
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_DisposeVehicle.py'])
