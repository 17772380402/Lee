from project.utils.HttpMethod import *
import pytest

'''
查询车辆信息详情
'''

id = "12880"


def test():
    url = "/api/v1/webapp/asset/vehicle/" + str(id)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryVehicleById.py'])
