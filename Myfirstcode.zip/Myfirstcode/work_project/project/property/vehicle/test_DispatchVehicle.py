from project.utils.HttpMethod import *
import pytest

'''
发车
'''

id = 26397


def test():
    url = "/api/v1/webapp/asset/vehicle/departure"
    data = [id]
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_DispatchVehicle.py'])
