from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.vehicleData import *
import pytest

'''
新增车辆
'''

modelId = "27540"  # 测试环境专用方案车型(领雅2008 1.4T)
# modelId = "29147"  # 测试环境专用方案车型("比亚迪 E5-400")
type = "13403"  # 测试环境专用方案车辆类型(小型汽车)


def test():
    url = "/api/v1/webapp/asset/vehicle"
    data = {
        # "bambooCar": true,
        "certDate": registerDate,
        "color": color,
        "engineNo": engineNo,
        "modelId": modelId,
        "owner": name,
        "partnerId": 0,
        "partnerType": 0,
        "plate": plate,
        "registerDate": registerDate,
        # "remark": "string",
        # "scrapInfo": "string",
        "transportCert": True,
        "type": type,
        "useType": useType,
        "validDate": validDate,
        "vinCode": vinCode
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddVehicle.py'])
