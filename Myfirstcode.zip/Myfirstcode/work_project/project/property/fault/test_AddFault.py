from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.faultData import *
import pytest

'''
新增故障
'''
vehicleId = 36794
processType = 15404

def test():
    url = "/api/v1/webapp/asset/fault"
    data = {
        "faultDate": nowDate,
        "faultTypeList": [int(faultType)],
        "faultTypes": faultType,
        "operation": True,
        "processType": processType,
        "reportMobile": mobile,
        "reportName": name,
        "vehicleId": vehicleId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddFault.py'])
