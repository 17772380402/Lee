from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.faultData import *
import pytest

'''
新增拖车
'''
faultId = 92699


def test():
    url = "/api/v1/webapp/asset/fault/trailer"
    data = {
        "costHolder": costHolder,
        "faultId": faultId,
        "faultTypeList": [],
        "fee": 1000 * 100,
        "payFee": True,
        "source": 0,
        "tailerCompany": "测试拖车公司",
        "tailerDate": nowDate
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddTrailer.py'])
