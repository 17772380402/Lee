from project.utils.HttpMethod import *
import pytest

'''
查询车损费用管理列表
'''
maintainStatus = "16502"  # 未处理:16501, 处理中:16502, 已完成:16503


def test():
    url = "/api/v1/webapp/asset/maintenance/cost/list"
    data = {
        # "corpId": "",
        "maintainStatus": maintainStatus,
        # "modelId": None,
        "pageIndex": 1,
        "pageSize": 20,
        # "plate": ""
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryMaintenanceCostList.py'])
