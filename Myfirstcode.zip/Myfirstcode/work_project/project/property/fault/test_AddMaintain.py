from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.faultData import *
from project.utils.data.insuranceData import *
import pytest

'''
新增保养
'''
f = Faker(locale='zh_CN')


def cost():
    fee = f.random_int(0, 10000) * 100
    return fee


vehicleId = 26372
materialFee = cost()
otherFee = cost()
personFee = cost()


def test():
    url = "/api/v1/webapp/asset/maintain"
    data = {
        "costHolder": costHolder,
        "maintainDateStr": nowDate,
        "maintainOwner": "中国平安",
        # "maintainProject": "",
        "materialFee": materialFee,
        "meter": 100,
        "operation": True,
        "otherFee": otherFee,
        "personFee": personFee,
        "sendOwner": insuranceIdentity,
        "totalFee": materialFee + otherFee + personFee,
        # "upKeepFeeItem": [{}],
        "vehicleId": vehicleId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddMaintain.py'])
