from project.utils.HttpMethod import *
import pytest

'''
保存结案资料
'''

outInsuranceId = 2323


def test():
    url = "/api/v1/webapp/out/insurance/close/save"
    data = {
        # "corpId": 0,
        "dingRemark": "结案",
        # "id": id,
        "outInsuranceId": outInsuranceId,
        # "tenantId": 0,
        # "user": {
        #     "admin": true,
        #     "avatar": "string",
        #     "bizLine": "string",
        #     "bizLineEnumList": [
        #         "SALES"
        #     ],
        #     "boss": true,
        #     "corpId": 0,
        #     "creatorId": 0,
        #     "defaultCorpName": "string",
        #     "dingDept": "string",
        #     "email": "string",
        #     "gmtCreate": "2020-11-23T09:24:04.991Z",
        #     "gmtModify": "2020-11-23T09:24:04.991Z",
        #     "hiddenMobile": true,
        #     "hiredDate": "string",
        #     "id": 0,
        #     "jobNumber": "string",
        #     "mobile": "string",
        #     "name": "string",
        #     "operatorUser": {
        #         "corpId": 0,
        #         "operatorUserId": 0,
        #         "operatorUserName": "string"
        #     },
        #     "orgEmail": "string",
        #     "position": "string",
        #     "remark": "string",
        #     "roleId": "string",
        #     "senior": true,
        #     "status": true,
        #     "tel": "string",
        #     "tenantId": 0,
        #     "unionCode": "string",
        #     "userCode": "string",
        #     "workPlace": "string"
        # }
    }
    return HttpMethod(url).put(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_CloseInsuranceAndSave.py'])
