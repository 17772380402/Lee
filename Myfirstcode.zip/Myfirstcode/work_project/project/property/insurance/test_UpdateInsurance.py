from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.insuranceData import *
import pytest

'''
编辑保单
'''


def test():
    url = "/api/v1/webapp/insurance"
    insuranceType1 = "13601"
    insuranceType2 = "13602"
    insuranceNo1 = "44842984660"
    insuranceNo2 = "636944411668"
    insuranceId1 = 3019
    insuranceId2 = 3020
    insuranceCost = 9879 * 100
    insuranceIdentity = 13702

    data1 = {
        "company": insuranceCompany,
        "cost": insuranceCost,
        "endDate": futureDate,
        "insuranceArea": insuranceCompany + "支行",
        "insuranceIdentity": insuranceIdentity,
        "insuranceNo": insuranceNo1,
        "insuranceType": insuranceType1,
        # "remark": "string",
        "seatInsu": True,
        "startDate": pastDate,
        "insuranceId": insuranceId1,
    }
    data2 = {
        "company": insuranceCompany,
        "cost": insuranceCost,
        "endDate": futureDate,
        "insuranceArea": insuranceCompany + "支行",
        "insuranceIdentity": insuranceIdentity,
        "insuranceNo": insuranceNo2,
        "insuranceType": insuranceType2,
        # "remark": "string",
        "seatInsu": True,
        "startDate": pastDate,
        "insuranceId": insuranceId2,
    }
    HttpMethod(url).put(data1)
    HttpMethod(url).put(data2)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_UpdateInsurance.py'])
