from project.utils.HttpMethod import *
import pytest

'''
查询出险列表
'''


def test():
    url = "/api/v1/webapp/out/insurance/list"
    data = {
        # "corpId": 0,
        # "corpIdList": [
        #     0
        # ],
        # "corpIds": [
        #     0
        # ],
        # "creatorId": 0,
        # "endDate": "2020-11-23T03:18:55.311Z",
        # "endDateStr": "string",
        # "export": true,
        # "gmtCreate": "2020-11-23T03:18:55.311Z",
        # "gmtModify": "2020-11-23T03:18:55.311Z",
        # "id": 0,
        # "keyword": "string",
        # "offset": 0,
        # "operatorUser": {
        #     "corpId": 0,
        #     "operatorUserId": 0,
        #     "operatorUserName": "string"
        # },
        # "pageIndex": 0,
        # "pageSize": 0,
        # "plate": "string",
        # "processStatus": "string",
        # "reportCode": "string",
        # "responsibilityType": "string",
        # "startDate": "2020-11-23T03:18:55.311Z",
        # "startDateStr": "string",
        # "tenantId": 0,
        # "totalFeeFrom": 0,
        # "totalFeeTo": 0
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryOutInsuranceList.py'])
