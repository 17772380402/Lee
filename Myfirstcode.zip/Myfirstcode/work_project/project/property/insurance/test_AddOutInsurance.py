from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.insuranceData import *
import pytest

'''
新增出险
'''

vehicleId = 36796


def test():
    url = "/api/v1/webapp/out/insurance"
    data = {
        "accidentType": accidentType,
        "area": addr,
        "closingStatus": True,
        "code": outInsuranceCode,
        # "createrId": 0,
        # "createrName": "string",
        # "dingRemark": "string",
        # "gmtCreate": "2020-11-20T02:34:01.761Z",
        # "gmtModify": "2020-11-20T02:34:01.761Z",
        # "id": 0,
        # "label": "string",
        "mobile": mobile,
        # "outInsuranceDate": outInsuranceDate,
        "outInsuranceDateStr": outInsuranceDate,
        "person": name,
        # "remark": "string",
        "reportCode": "{}*{}".format(outInsuranceCode, insuranceCompany),
        "reportNo": {
            # "id": "",
            "number": outInsuranceCode,
            "corpId": insuranceCompany,
        },
        "responsibilityType": responsibilityType,
        # "thingLossFee": 0,
        # "thirdPartyLossFee": 0,
        # "totalFee": 0,
        # "vehicleFee": 0,
        "vehicleId": vehicleId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddOutInsurance.py'])
