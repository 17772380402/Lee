from project.utils.HttpMethod import *
from project.utils.DataUtils import *
import pytest

'''
送修
'''

faultId = 92699
meter = "100"
source = 0


def test():
    url = "/api/v1/webapp/asset/fault/send/Repair"
    data = {
        # "corpId": 0,
        "faultId": faultId,
        "faultTypeList": [],
        # "id": 0,
        "meter": meter,
        "receiver": "测试",
        "repairOwner": "测试资产服务公司",
        "returnDate": nowDate,
        "source": source,
        # "tenantId": 0,
        "toDate": pastDate,
        # "user": {
        #     "admin": True,
        #     "avatar": "string",
        #     "bizLine": "string",
        #     "bizLineEnumList": [
        #         "SALES"
        #     ],
        #     "boss": True,
        #     "corpId": 0,
        #     "creatorId": 0,
        #     "defaultCorpName": "string",
        #     "dingDept": "string",
        #     "email": "string",
        #     "gmtCreate": "2020-11-23T07:10:20.496Z",
        #     "gmtModify": "2020-11-23T07:10:20.496Z",
        #     "hiddenMobile": True,
        #     "hiredDate": "string",
        #     "id": 0,
        #     "jobNumber": "string",
        #     "mobile": "string",
        #     "name": "string",
        #     "operatorUser": {
        #         "corpId": 0,
        #         "operatorUserId": 0,
        #         "operatorUserName": "string"
        #     },
        #     "orgEmail": "string",
        #     "position": "string",
        #     "remark": "string",
        #     "roleId": "string",
        #     "senior": True,
        #     "status": True,
        #     "tel": "string",
        #     "tenantId": 0,
        #     "unionCode": "string",
        #     "userCode": "string",
        #     "workPlace": "string"
        # }
    }
    return HttpMethod(url).put(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_SendRepair.py'])
