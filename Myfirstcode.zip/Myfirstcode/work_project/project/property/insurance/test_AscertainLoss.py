from project.utils.HttpMethod import *
from project.utils.DataUtils import *
import pytest

'''
定损
'''
accidentPenalty = "10000"
mobile = "14723641909"
name = "国慧"
outInsuranceId = 8302
plate = "贵H06312"
fee = "100"
insurancePayPerson = "16602"
vehicleId = 36796
type = "16201"


def test():
    url = "/api/v1/webapp/asset/ascertain"
    data = {
        "ascertainLossHeadDTO": {
            "accidentPenalty": accidentPenalty,
            # "corpId": 0,
            # "creatorId": 0,
            # "gmtCreate": "2020-11-23T03:33:44.794Z",
            # "gmtModify": "2020-11-23T03:33:44.794Z",
            # "id": 0,
            "mobile": mobile,
            # "myCarFee": 0,
            # "myCarPersonFee": 0,
            "name": name,
            # "operatorUser": {
            #     "corpId": 0,
            #     "operatorUserId": 0,
            #     "operatorUserName": "string"
            # },
            "outInsuranceId": outInsuranceId,
            "payRatio": 100,
            # "paySide": "string",
            # "personFillStatus": True,
            "plate": plate,
            "quickPay": True,
            "receivedFine": True,
            # "tenantId": 0,
            # "thingFee": 0,
            # "thingFillStatus": True,
            # "threePartyCarFee": 0,
            # "threePartyPersonFee": 0,
            # "trailerFee": 0,
            "trailerFeeExist": False,
            "trailerFeeList": [
                # {
                #     "id": 0,
                #     "refId": 0,
                #     "source": 0,
                #     "trailerFee": 0,
                #     "type": "string",
                #     "typeName": "string"
                # }
            ],
            # "vehicleFillStatus": True,
            "vehicleId": vehicleId
        },
        "personLossList": [
            # {
            #     "ascertainLossId": 0,
            #     "attachNames": "string",
            #     "fee": 0,
            #     "id": 0,
            #     "identityCardNum": "string",
            #     "insurancePayPerson": "string",
            #     "insurancePayPersonDesc": "string",
            #     "mobile": "string",
            #     "name": "string",
            #     "outInsuranceId": 0,
            #     "payFee": 0,
            #     "payPersonCard": "string",
            #     "payPersonName": "string",
            #     "payStatus": True,
            #     "remark": "string",
            #     "type": "string"
            # }
        ],
        "thingLossList": [
            # {
            #     "ascertainLossId": 0,
            #     "attachNames": "string",
            #     "contacts": "string",
            #     "fee": 0,
            #     "id": 0,
            #     "insurancePayPerson": "string",
            #     "insurancePayPersonDesc": "string",
            #     "mobile": "string",
            #     "outInsuranceId": 0,
            #     "payFee": 0,
            #     "payPersonCard": "string",
            #     "payPersonName": "string",
            #     "payStatus": True,
            #     "remark": "string",
            #     "type": "string"
            # }
        ],
        "vehicleLossList": [
            {
                # "ascertainLossId": 0,
                # "attachNames": "string",
                "driver": name,
                # "drivingLicenseNum": "string",
                "fee": fee,
                # "id": 0,
                "insurancePayPerson": insurancePayPerson,
                # "insurancePayPersonDesc": "string",
                "mobile": mobile,
                "outInsuranceId": outInsuranceId,
                # "payFee": 0,
                # "payPersonCard": "string",
                # "payPersonName": "string",
                "payStatus": False,
                "plate": plate,
                "repayStatus": False,
                "type": type,
                # "vehicleId": 0
            }
        ]
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AscertainLoss.py'])
