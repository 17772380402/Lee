from project.utils.HttpMethod import *
from project.utils.data.faultData import *
import pytest

'''
维修
'''

faultId = "92699"
repairType = "15701"  # 故障维修:15701, 事故维修:15702, 资产维保:15703
source = 0


def test():
    url = "/api/v1/webapp/asset/repair"
    data = {
        "batteryDamage": False,
        "costHolder": costHolder,
        "faultId": faultId,
        "materialFee": 0,
        "materialFeeItems": [],
        "otherFee": 0,
        "otherFeeItems": [],
        "personFee": 0,
        "personFeeItems": [],
        "repairType": repairType,
        "source": source,
        "totalFee": 0,
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Repair.py'])
