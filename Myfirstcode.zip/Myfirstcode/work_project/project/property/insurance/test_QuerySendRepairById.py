from project.utils.HttpMethod import *
import pytest

'''
id查询送修
'''

id = "2316"
source = 1


def test():
    url = "/api/v1/webapp/asset/fault/send/Repair?faultId=" + str(id) + "&source=" + str(
        source)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QuerySendRepairById.py'])
