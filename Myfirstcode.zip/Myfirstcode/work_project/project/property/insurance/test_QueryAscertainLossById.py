from project.utils.HttpMethod import *
import pytest

'''
id查询定损
'''

outInsuranceId = 2316
type = "16201"


def test():
    url = "/api/v1/webapp/asset/ascertain/loss/info/" + str(outInsuranceId) + "/" + str(
        type)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryAscertainLossById.py'])
