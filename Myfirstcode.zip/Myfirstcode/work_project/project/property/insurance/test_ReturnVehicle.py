from project.utils.HttpMethod import *
from project.utils.DataUtils import *
import pytest

'''
取车
'''

faultId = 92699
personName = "测试"
source = 0


def test():
    url = "/api/v1/webapp/asset/fault/returnVehicle"
    data = {
        "actualReturnDate": nowDate,
        # "corpId": 0,
        # "creatorId": 0,
        "dayExpenditure": "0",
        "faultId": faultId,
        "faultTypeList": [],
        # "gmtCreate": "2020-11-23T07:57:04.880Z",
        # "gmtModify": "2020-11-23T07:57:04.880Z",
        # "id": 0,
        # "operatorUser": {
        #     "corpId": 0,
        #     "operatorUserId": 0,
        #     "operatorUserName": "string"
        # },
        "personName": personName,
        "source": source,
        # "tenantId": 0
    }
    return HttpMethod(url).put(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_ReturnVehicle.py'])
