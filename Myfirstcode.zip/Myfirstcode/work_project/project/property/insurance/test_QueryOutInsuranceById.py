from project.utils.HttpMethod import *
import pytest

'''
id查询出险
'''

id = "2320"


def test():
    url = "/api/v1/webapp/out/insurance/detail/" + str(id)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryOutInsuranceById.py'])
