from project.utils.HttpMethod import *
import pytest

'''
出险销案
'''

id = "2303"


def test():
    url = "/api/v1/webapp/out/insurance/remove/" + str(id)
    return HttpMethod(url).delete()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_DeleteOutInsurance.py'])
