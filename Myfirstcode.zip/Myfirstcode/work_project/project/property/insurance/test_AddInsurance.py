from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.insuranceData import *
import pytest

'''
新增保单
'''

f = Faker(locale='zh_CN')
url = "/api/v1/webapp/insurance"
vehicleId = 26397
insuranceType1 = "13601"
insuranceType2 = "13602"


def test1():
    data1 = {
        "company": insuranceCompany,
        "cost": f.random_int(0, 10000) * 100,
        "endDate": futureDate,
        "insuranceArea": insuranceCompany + "支行",
        "insuranceIdentity": insuranceIdentity,
        "insuranceNo": f.random_number(12),
        "insuranceType": insuranceType1,
        # "remark": "string",
        "seatInsu": True,
        "startDate": pastDate,
        "vehicleId": vehicleId
    }
    return HttpMethod(url).post(data1)


def test2():
    data2 = {
        "company": insuranceCompany,
        "cost": f.random_int(0, 10000) * 100,
        "endDate": futureDate,
        "insuranceArea": insuranceCompany + "支行",
        "insuranceIdentity": insuranceIdentity,
        "insuranceNo": f.random_number(12),
        "insuranceType": insuranceType2,
        # "remark": "string",
        "seatInsu": True,
        "startDate": pastDate,
        "vehicleId": vehicleId
    }
    return HttpMethod(url).post(data2)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddInsurance.py'])
