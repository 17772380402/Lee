from project.utils.HttpMethod import *
import pytest

'''
查询年检登记
'''
plate = "自A67801"


def test():
    url = "/api/v1/webapp/asset/inspect/query"
    data = {
        # "corpId": None,
        # "costHolder": costHolder,
        "keyword": plate,
        "pageIndex": 1,
        "pageSize": 20,
        # "transactorType": transactorType,
        # "type": 1,
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryInspection.py'])
