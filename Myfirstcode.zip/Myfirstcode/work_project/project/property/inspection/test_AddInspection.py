from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.inspectionData import *
import pytest

'''
新增年检登记
'''
vehicleId = "36792"


def test():
    url = "/api/v1/webapp/asset/inspect/save"
    data = {
        # "attachmentList": [],
        "costHolder": costHolder,
        "fee": cost,
        "inspectDate": dateStr2,
        "inspectOffice": "test",
        "oldValidDate": validDate,
        # "plate": plate,
        "qualifiedDesc": "合格",
        "transactorType": transactorType,
        # "type": 1,
        "validDate": validDate,
        "vehicleId": vehicleId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddInspection.py'])
