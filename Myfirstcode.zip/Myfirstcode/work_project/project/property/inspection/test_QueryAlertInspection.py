from project.utils.HttpMethod import *
import pytest

'''
查询年检提醒
'''
corpId = 105338612
useType = "13301"  # 待整备:13301, 运营:13302, 非运营:13303, 处置:13304


def test():
    url = "/api/v1/webapp/asset/inspect/alert"
    data = {
        "corpId": corpId,
        # "dateDay": "",
        # "managerUserId": None,
        # "keyword": plate,
        "pageIndex": 1,
        "pageSize": 20,
        "useType": useType
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryAlertInspection.py'])
