from project.utils.HttpMethod import *
import pytest

'''
查询待审批合同列表
'''

auditStatus = 18501  # 审核状态 待审核:18501
contractCode = "G202012297401"


def test():
    url = "/api/v1/webapp/contract/audit/list"
    data = {
        "auditStatus": [auditStatus],
        "keyword": contractCode
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryAuditList.py'])
