from project.utils.HttpMethod import *
import pytest

'''
id查询合同
'''

id = "70755"


def test():
    url = "/api/v1/webapp/contract/" + id
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryContractById.py'])
