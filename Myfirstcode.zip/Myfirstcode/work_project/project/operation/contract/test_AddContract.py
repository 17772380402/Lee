from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.contractData import *
import pytest

'''
新增合同
'''

custId = 324132143214350
custName = "谢秀珍"
idNo = "430721197111076481"
mobile = "15852034196"
modelId = 27540
vehicleId = 26163
vehiclePlate = "宁D16986"
engineNo = "75353127"
vin = "UV571ARM4TBJ0WKBE"
productType = 10901  # 业务类型 10901:以租代购，10902:经营租赁
# productId = 609  # 产品方案 600:测试自营3，605:测试自营5
productId = 1059  # 产品方案 600:测试自营3，605:测试自营5
# productName = "测试自营3"  # 产品方案名称(与产品方案绑定)
productName = "领雅 2008款 1.4T 活力版集团总部3.1-3.31基础方案以租代购0325测试完单量减免"  # 产品方案名称(与产品方案绑定)
# rent = "793/5000/0/6/0/15"  # 租期方案(与产品方案绑定)
rent = "1363/5000/0/6/0/15"  # 租期方案(与产品方案绑定)
# rentId = 793  # 租期id(与产品方案绑定)
rentId = 1363  # 租期id(与产品方案绑定)
tenancy = 6  # 租期(与产品方案绑定)
extensionTenancy = 15  # 扩展租期(与产品方案绑定)
deposit = 300000  # 押金(与产品方案绑定)
unitPrice = 500000  # 每期租金(与产品方案绑定)
deptId = -727379968  # 99674239
signBodyId = 177


def test():
    url = "/api/v1/webapp/contract"
    data = {
        "basic": {
            "appOnline": False,
            "attachmentList": [
            ],
            "attachments": [
            ],
            "collectRentDay": collectRentDay,
            "contractCode": contractCode,
            "custId": custId,
            "custName": custName,
            "deposit": deposit,
            "deptId": deptId,
            "endDate": endDate,
            "engineNo": engineNo,
            "extensionTenancy": extensionTenancy,
            "firstPayment": 100000,
            "floatPrice": 0,
            # "gmtCreate": "2020-06-01T15:52:02+08:00",
            # "gmtModify": "2020-10-30T13:34:18+08:00",
            "id": productId,
            "idNo": idNo,
            "manageFees": 10000,
            "mobile": mobile,
            "modelId": modelId,
            "modelName": "领雅 2008款 1.4T 活力版",
            "onlyRenew": 1,
            "operatorId": 570,
            "operatorName": "张斌",
            "partnerBizType": "",
            "platform": platform,
            "productId": productId,
            "productIdAndActivityId": "0-0-0",
            "productName": productName,
            "productType": productType,
            "rent": rent,
            "rentId": rentId,
            "signBodyId": signBodyId,
            "startDate": startDate,
            "tailPayment": 50000,
            "tenancy": tenancy,
            "travelPlatform": travelPlatform,
            "unitPrice": unitPrice,
            "vehicleId": vehicleId,
            "vehiclePlate": vehiclePlate,
            "vin": vin,
        },
        "expandMap": {},
        "hirePurchase": {},
        "instalmentLease": {
            "instalmentModelList": [],
            "rentPayType": "14702",
            "rentPayTypeDesc": "银行委托扣款",
            "withdrawType": 1,
        },
        "operationLease": {},
        "plateLease": {},
        "supplementParam": {
            "attachments": [
                {
                    "0": {
                        "fileName": "2020122900000044.jpg",
                        "id": None,
                        "name": "2020122900000044.jpg",
                        "ossAttachUrl": None,
                        "refId": 324132143214353,
                        "refType": "CUSTOMER",
                        "subType": "DRIVING_PERMIT_FRONT",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000044.jpg?Expires=1609210483&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=XqaCAA8prVJ6mfXfJS3EqG3ojdk%3D",
                        "variable": "drivingPermitFrontImages",
                    },
                    "1": {
                        "fileName": "2020122900000045.jpg",
                        "id": None,
                        "name": "2020122900000045.jpg",
                        "ossAttachUrl": None,
                        "refId": 324132143214353,
                        "refType": "CUSTOMER",
                        "subType": "DRIVING_PERMIT_REVERSE",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000045.jpg?Expires=1609210486&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=oGP6qDZI9%2Fgp7LiEifdw%2FrAoMYk%3D",
                        "variable": "drivingPermitReverseImages",
                    },
                    "2": {
                        "fileName": "2020122900000042.jpg",
                        "id": None,
                        "name": "2020122900000042.jpg",
                        "ossAttachUrl": None,
                        "refId": 324132143214353,
                        "refType": "CUSTOMER",
                        "subType": "ID_PERMIT_FRONT",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000042.jpg?Expires=1609210478&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=WiZOpVmQXqNqW672xPrU7nhaP34%3D",
                        "variable": "idPermitFrontImages",
                    },
                    "3": {
                        "fileName": "2020122900000043.jpg",
                        "id": None,
                        "name": "2020122900000043.jpg",
                        "ossAttachUrl": None,
                        "refId": 324132143214353,
                        "refType": "CUSTOMER",
                        "subType": "ID_PERMIT_REVERSE",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000043.jpg?Expires=1609210481&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=LxL%2FZVwBTgN57e6cUgRapysuqXE%3D",
                        "variable": "idPermitReverseImages",
                    },
                },
            ],
            "platform": platform,
            "platformNo": contractCode,
            "travelPlatform": "20302",
        },
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddContract.py'])
