from project.utils.HttpMethod import *
import pytest

'''
审批合同
'''

auditStatus = "18502"  # 审核状态 待审核:18501 审核通过:18502 审核不通过:18503 撤回:18504
id = 70903


def test():
    url = "/api/v1/webapp/contract/operate/audit"
    data = {
        'auditStatus': auditStatus,
        'id': id
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AuditContract.py'])
