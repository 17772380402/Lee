from project.utils.HttpMethod import *
import pytest

'''
合同补录结算信息
'''

contractId = ""


def test():
    '''
    正常到期:16701 违约退车:16702 强制退车:16703 劝退:16704
    '''
    returnType = "16701"
    url = "/api/v1/webapp/contract/settlement/" + contractId + "/" + returnType
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_ContractSettlement.py'])
