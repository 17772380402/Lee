from project.utils.HttpMethod import *
from project.utils.data.contractData import *
import pytest

'''
平账
'''

contractId = 70934
periodId = 62419
amount = 853000

def test():
    url = "/api/v1/webapp/contract/period/payment"
    data = {
        "amount": amount,
        "contractId": contractId,
        "payTime": startDate,
        "paymentType": paymentType,
        "periodId": periodId,
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_ContractPayment.py'])
