from project.utils.HttpMethod import *
from project.utils.data.contractData import *
import pytest

'''
合同延期
'''

id = 70046


def test():
    url = "/api/v1/webapp/contract/operate/contractExtend"
    extendDays = 1
    extendFees = 0
    reason = "合同延期"
    data = {
        # "attachments": [
        #     "string"
        # ],
        "extendDays": extendDays,
        "extendFees": extendFees,
        "id": id,
        "reason": reason,
        "reduceProject": reduceProject,
        # "remark": "string"
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_ExtendContract.py'])
