from project.utils.HttpMethod import *
import pytest

'''
合同补录入库信息
'''

contractId = ""


def test():
    '''
    合同创建:15001 暂退签约:15002 合同提车:15003 违约换车:15004 合同退车:15005 合同暂退:15006
    合同续约:15007 合同延期:15008 合同变更:15009 合同结束:15010 合同转让:15011
    '''
    sourceCode = "15001"
    url = "/api/v1/webapp/contract/indepot/" + contractId + "/" + sourceCode
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_ContractDepotIn.py'])
