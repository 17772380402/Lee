from project.utils.HttpMethod import *
import pytest

'''
查询合同租期账单
'''

contractId = "70948"


def test():
    url = "/api/v1/webapp/contract/period/bill?contractId=" + str(contractId)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryContractPeriodBill.py'])
