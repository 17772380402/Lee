from project.utils.HttpMethod import *
import pytest

'''
查询车队
'''


def test():
    url = "/api/v1/wabapp/vehicleteam/list"
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryVehicleTeamList.py'])
