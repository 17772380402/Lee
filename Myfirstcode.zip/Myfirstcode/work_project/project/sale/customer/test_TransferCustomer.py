from project.utils.HttpMethod import *
import pytest

'''
转移客户给他人
'''

custId = "324132143214407"
receiveId = 152


def test():
    url = "/api/v1/webapp/crm/customer/transfer"
    data = {
        "custIds": [
            custId
        ],
        "receiveId": receiveId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_TransferCustomer.py'])
