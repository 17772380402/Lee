from project.utils.HttpMethod import *
import pytest

'''
转移客户给公海
'''

id = 324132143214246


def test():
    url = "/api/v1/crmcore/public/transfer/sea"
    data = {
        "ids": [
            id
        ]
    }
    return HttpMethod(url).put(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_TransferCustomerToSea.py'])
