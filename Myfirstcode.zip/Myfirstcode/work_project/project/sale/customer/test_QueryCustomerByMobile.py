from project.utils.HttpMethod import *
import pytest

'''
手机号查询客户
'''

mobile = "17123303607"


def test():
    url = "/api/v1/webapp/crm/customer/one/" + mobile
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryCustomerByMobile.py'])
