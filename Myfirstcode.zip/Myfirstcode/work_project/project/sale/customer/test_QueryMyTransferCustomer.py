from project.utils.HttpMethod import *
import pytest

'''
查询我转出的客户
'''


def test():
    url = "/api/v1/webapp/crm/customer/transfer/out"
    # 转移状态 11801: 已转出, 11802: 未完成, 11803: 已接收, 11804: 待接收, 11805: 已撤回
    transferStatus = 11803
    data = {
        # "custLevel": "string",
        # "deptId": 0,
        # "keyword": "string",
        "pageIndex": 1,
        "pageSize": 10,
        # "source": "string",
        "transferStatus": transferStatus
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryMyTransferCustomer.py'])
