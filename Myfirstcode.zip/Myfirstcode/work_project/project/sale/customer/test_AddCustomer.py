from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.customerData import *
import pytest

'''
新增客户
'''
introductionMobile = 1371650482
introductionName = "曾佑祖"


def test():
    url = "/api/v1/webapp/crm/customer"
    data = {
        "addr": addr,
        # "age": 0,
        # "city": "string",
        # "contact": "string",
        # "contactRelation": "string",
        # "contactTelephone": "string",
        # "criminalRecord": true,
        "custLevel": custLevel,
        "custName": name,
        # "didiAccount": "string",
        # "drivingAge": 0,
        # "gender": "string",
        "idNo": idNo,
        # "interviewJob": "string",
        "introductionMobile": introductionMobile,
        "introductionName": introductionName,
        "introductionStatus": True,
        # "majorTrafficAcc": true,
        "mobile": mobile,
        # "nativePlace": "string",
        # "networkCarLic": true,
        # "remark": "string",
        "bank": bank,
        "bankCardNo": bankCardNo,
        # "secretNumber": "string",
        "source": source,
        # "uniqueMark": "string"
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddCustomer.py'])
