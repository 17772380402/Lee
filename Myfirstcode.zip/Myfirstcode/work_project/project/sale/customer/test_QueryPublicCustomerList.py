from project.utils.HttpMethod import *
import pytest

'''
查询公海客户列表
'''


def test():
    url = "/api/v1/crmcore/public/list/"
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryPublicCustomerList.py'])
