from project.utils.HttpMethod import *
import pytest

'''
转移客户给自己
'''

id = 324132143214246


def test():
    url = "/api/v1/crmcore/public/transfer/self"
    data = {
        "ids": [
            id
        ]
    }
    return HttpMethod(url).put(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_TransferCustomerToMyself.py'])
