from project.utils.HttpMethod import *
import pytest

'''
id查询客户
'''

id = "324132143214421"


def test():
    url = "/api/v1/webapp/crm/customer/" + str(id)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryCustomerById.py'])
