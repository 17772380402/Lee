from project.utils.HttpMethod import *
import pytest

'''
查询所有客户
'''


def test():
    url = "/api/v1/webapp/crm/customer/all"
    data = {}
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryAllCustomer.py'])
