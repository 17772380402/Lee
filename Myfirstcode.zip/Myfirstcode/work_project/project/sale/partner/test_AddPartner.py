from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.partnerData import *
import pytest

'''
新增大客户
'''
corpId = 105338612
partnerManager = "张斌"
partnerManagerId = 570


def test():
    url = "/api/v1/webapp/partner"
    data = {
        "bankCode": bankCode,
        # "bankName": "string",
        "bankNumber": bankNumber,
        "contactMobile": mobile,
        "contactPerson": name,
        "corpId": corpId,
        # "corpName": "string",
        # "createUserId": 0,
        # "creatorId": 0,
        "creditNumber": randomNum,
        "establishedTime": dateStr1,
        "gmtCreate": dateStr1,
        # "gmtModify": "2020-11-20T03:31:18.704Z",
        # "id": 0,
        "legalIdNo": idNo,
        "legalName": name,
        "manageAddress": addr,
        # "modifyUserId": 0,
        "name": companyName,
        "operatorUser": {
            "corpId": corpId,
            # "operatorUserId": 0,
            # "operatorUserName": "string"
        },
        "partnerManager": partnerManager,
        "partnerManagerId": partnerManagerId,
        # "partnerStatus": "string",
        # "remark": "string",
        "source": partnerSource,
        "status": True,
        "subbranchBank": bankCode,
        # "tenantId": 0,
        # "type": 0
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddPartner.py'])
