from project.utils.HttpMethod import *
import pytest

'''
id查询大客户
'''

id = "1084"


def test():
    url = "/api/v1/webapp/partner/detail/" + str(id)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryPartnerById.py'])
