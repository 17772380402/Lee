import pytest

from project.utils.HttpMethod import HttpMethod

url="/api/v1/webapp/sale/policy/create"
name="2020122700000002.jpg"
ossAttachUrl= "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122700000002.jpg?Expires=1609055931&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=GRT%2BmaxBTeH%2BNFGZKysChd%2F3tik%3D"
type="image/jpeg"
corpId=99940212
leaseTerm="1"
rewardType= "2"
timeDimensionType= "1"
policyType="1"
validEndDate= "2023-01-31"
validStartDate="2020-12-27"


def test():
    data = {
        "attachmentList": [
            {
                "name": name,
                "ossAttachUrl": ossAttachUrl,
                "type": type,
                "url":ossAttachUrl
            }
        ],
        "corpId": corpId,
        "policyConfigDTO": {
            # "accessCondition": "string",
            # "businessType": "string",
            # "businessTypeDesc": "string",
            # "corpId": 0,
            # "creatorId": 0,
            # "customProperty": "string",
            # "gmtCreate": "2020-12-27T07:14:51.605Z",
            # "gmtModify": "2020-12-27T07:14:51.605Z",
            # "id": 0,
            # "modelId": 0,
            # "modelName": "string",
            # "operatorUser": {
            #     "corpId": 0,
            #     "operatorUserId": 0,
            #     "operatorUserName": "string"
            "leaseTerm":leaseTerm,
            # period: ""
            # rewardConfigDTOS: []
            "rewardType": rewardType,
            # termNum: []
            "timeDimensionType": timeDimensionType
            },
        "policyType": policyType,
        "validEndDate": validEndDate,
        "validStartDate": validStartDate
    }

    return HttpMethod(url).post(data)


if __name__ == "__main__":
    pytest.main(['-s', '-v', 'test_AddSalesPolicy.py'])
