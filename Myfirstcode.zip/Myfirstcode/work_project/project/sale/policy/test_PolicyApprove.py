import pytest
from project.utils.HttpMethod import HttpMethod

"""
策略审批
"""

approvalType= 2
refId=36
url="/api/v1/webapp/approval/approve"
def test():
    data={
        "approvalType": approvalType,
        "pass":True,
        "refId":refId,
    }
    return HttpMethod(url).post(data)

if __name__ == '__main__':
    pytest.main(['-s','-v','test_PolicyApprove.py'])