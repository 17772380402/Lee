
from project.utils.DataUtils import *
from project.utils.HttpMethod import *
from project.utils.data.customerData import *
import pytest

'''
新增意向订单
'''


cityId="99674239"
# contact="蒋一"
# contactTelephone="17720202020"
custId=51566
# custName="蒋一一"
drip= "13801"
# idNo="140401199701288327"
# mobile= "17772380402"
networkCarLic="0"
ownerId=709
productId= 520
productListId= 295
remarks: ""
rentId=690
ownerId=709

def test():
    url="/api/v1/crmapp/intentionOrder/create"

    data = {
        "cityId": cityId,
        "contact": name,
        "contactTelephone": mobile,
        "custName": name,
        "drip": drip,
        # "hasResidentLiscence": true,
        "idNo": idNo,
        # "introduceMobile": introduceMobile,
        # "introduceName": introduceName,
        "mobile": mobile,
        # "networkCarLic": true,
        "productId": productId,
        # "productType": 0,
        "productListId": productListId,
        # "remarks": "string",
        "rentId": rentId,
        "source": source,
        "ownerId":ownerId
    }
    return HttpMethod(url).post1(data)

if __name__== '__main__':
    pytest.main(['-s','-v','test_AddIntentionOrder.py'])


