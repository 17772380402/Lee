from project.utils.HttpMethod import *
import pytest

'''
意向单设置为免付状态
'''

id = "1448"


def test():
    url = "/api/v1/webapp/intentionOrder/notPayment/" + str(id)
    data = {}
    return HttpMethod(url).put(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_NotPayment.py'])
