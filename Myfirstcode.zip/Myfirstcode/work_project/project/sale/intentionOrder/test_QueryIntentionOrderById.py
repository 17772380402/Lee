from project.utils.HttpMethod import *
import pytest

'''
id查询意向单明细
'''

id = "1643"


def test():
    url = "/api/v1/webapp/intentionOrder/" + str(id)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryIntentionOrderById.py'])
