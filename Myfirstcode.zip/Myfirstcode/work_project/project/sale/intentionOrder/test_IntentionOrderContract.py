from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.contractData import *
import pytest

'''
意向单新增合同
'''

custId = 51566
custName = "李莹"
idNo = "360424195410239768"
mobile = "18818275205"
modelId = 29162
vehicleId = 13325
vehiclePlate = "苏ED08651"
engineNo = "118034898"
vin = "LGXCE6DB3J0192225"
productType = 10902  # 业务类型 10901:以租代购，10902:经营租赁
productId = 520
productName = "销售方案减免测试1"  # 产品方案名称(与产品方案绑定)
rent = "690/4100/400/12/0/1"  # 租期方案(与产品方案绑定)
rentId = 690  # 租期id(与产品方案绑定)
tenancy = 12  # 租期(与产品方案绑定)
extensionTenancy = 1  # 扩展租期(与产品方案绑定)
deposit = 0  # 押金(与产品方案绑定)
unitPrice = 410000  # 每期租金(与产品方案绑定)
platform="19301"
intentionId= 1613
earnestMoney=100
deptId=99674239

def test():
    url = "/api/v1/webapp/contract"
    data = {
        "basic": {
            "appOnline":True,
            "attachmentList": [
            ],
            "attachments": [
            ],
            "collectRentDay": collectRentDay,
            "contractCode": contractCode,
            "custId": custId,
            "custName": custName,
            "deposit": deposit,
            "deptId": deptId,
            "earnestMoney": earnestMoney,
            "endDate": endDate,
            "engineNo": engineNo,
            "extensionTenancy": extensionTenancy,
            # "firstPayment": 100000,
            "floatPrice": 0,
            # "gmtCreate": "2020-06-01T15:52:02+08:00",
            # "gmtModify": "2020-10-30T13:34:18+08:00",
            "id": productId,
            "idNo": idNo,
            "intentionId": intentionId,
            "manageFees": 22200,
            # "manageFees": 10000,
            "mobile": mobile,
            "modelId": modelId,
            "modelName": "比亚迪 E5-450",
            "onlyRenew": 1,
            "operatorId": 570,
            "operatorName": "张斌",
            "partnerBizType": "",
            "platform": platform,
            "productId": productId,
            "productIdAndActivityId": "0-520-0",
            "productName": productName,
            "productType": productType,
            "remark": "lee test",
            "rent": rent,
            "rentId": rentId,
            "service": 40000,
            "signBodyId": 45,
            "startDate": startDate,
            # "tailPayment": 50000,
            "tenancy": tenancy,
            "travelPlatform": travelPlatform,
            "unitPrice": unitPrice,
            "vehicleId": vehicleId,
            "vehiclePlate": vehiclePlate,
            "vin": vin,
        },
        "expandMap": {},
        "hirePurchase": {},
        "instalmentLease": {
            "instalmentModelList": [],
            "rentPayType": "14702",
            "rentPayTypeDesc": "银行委托扣款",
            "withdrawType": 1,
        },
        "operationLease": {},
        "plateLease": {},
        "supplementParam": {
            "attachments": [
                {
                    "0": {
                        "fileName": "2020122900000184.jpg",
                        "id": None,
                        "name": "2020122900000184.jpg",
                        "ossAttachUrl": None,
                        "refId": None,
                        "refType": "CUSTOMER",
                        "subType": "DRIVING_PERMIT_FRONT",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000184.jpg?Expires=1609237823&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=ieDKyqd6m5JN1wgP9dof5Qxi4fc%3D",
                        "variable": "drivingPermitFrontImages",
                    },
                    "1": {
                        "fileName": "2020122900000185.jpg",
                        "id": None,
                        "name": "2020122900000185.jpg",
                        "ossAttachUrl": None,
                        "refId": None,
                        "refType": "CUSTOMER",
                        "subType": "DRIVING_PERMIT_REVERSE",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000185.jpg?Expires=1609237828&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=uyK1VbGKIc2MROllBdYoJjc1aAw%3D",
                        "variable": "drivingPermitReverseImages",
                    },
                    "2": {
                        "fileName": "2020122900000182.jpg",
                        "id": None,
                        "name": "2020122900000182.jpg",
                        "ossAttachUrl": None,
                        "refId": None,
                        "refType": "CUSTOMER",
                        "subType": "ID_PERMIT_FRONT",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000182.jpg?Expires=1609237816&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=CZxJs5S80GT8nlSgtjtcwNI52R0%3D",
                        "variable": "idPermitFrontImages",
                    },
                    "3": {
                        "fileName": "2020122900000183.jpg",
                        "id": None,
                        "name": "2020122900000183.jpg",
                        "ossAttachUrl": None,
                        "refId": None,
                        "refType": "CUSTOMER",
                        "subType": "ID_PERMIT_REVERSE",
                        "type": None,
                        "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122900000183.jpg?Expires=1609237819&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=bQlTVv%2FdxWOF0Fou3GTxk7N3aqs%3D",
                        "variable": "idPermitReverseImages",
                    },
                },
            ],
            "platform": platform,
            "platformNo": contractCode,
            "travelPlatform": "20301",
        },
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_IntentionOrderContract.py'])
