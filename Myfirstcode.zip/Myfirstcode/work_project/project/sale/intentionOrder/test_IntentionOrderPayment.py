

'''
意向订单确认收款
'''
import pytest

from project.utils.HttpMethod import HttpMethod

url="/api/v1/webapp/intentionOrder/payment"
amount=100
intentionId= 1613
memo="Lee test 意向单"
payTime="2020-12-29T08:56:57.000Z"
paymentType= "现金"

def test():
    data={
  "amount": amount,
  # "billingId": 0,
  "intentionId": intentionId,
  "memo": memo,
  "payTime": payTime,
  "paymentType": paymentType
}
    return HttpMethod(url).post(data)

if __name__=="__main__":
    pytest.main(['-s','-v','test_IntentionOrderPayment.py'])