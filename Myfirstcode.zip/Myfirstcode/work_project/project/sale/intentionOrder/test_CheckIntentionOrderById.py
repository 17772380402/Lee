from project.utils.HttpMethod import *
import pytest

'''
意向单校验
'''

id = "1447"


def test():
    url = "/api/v1/webapp/intentionOrder/check/" + str(id)
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_CheckIntentionOrderById.py'])
