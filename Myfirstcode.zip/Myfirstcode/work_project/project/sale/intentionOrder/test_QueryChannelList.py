import pytest

from project.utils.HttpMethod import *

'''
查询渠道商列表
'''


def test():
    url = "/api/v1/webapp/intentionOrder/channel/list/"
    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_QueryChannelList.py'])
