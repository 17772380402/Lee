# test_ProductDetail
'''
产品方案详情
'''
import pytest
from project.utils.HttpMethod import *

productId="295"

def test():
    #tsp产品详情接口
    # url = "https://st-app.maxima-cars.com/api/v1/webapp/product/detail/" + str(productId)
    #APP产品详情接口（APP产品取得是tsp——“app_online”=1【已上线】的数据）
    url = "/api/v1/crmapp/product/detail/" + str(productId)


    return HttpMethod(url).get()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_ProductDetail.py'])
