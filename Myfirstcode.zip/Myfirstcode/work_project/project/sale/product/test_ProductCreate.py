


"""
新增产品方案
"""
import pytest

from project.utils.DataUtils import name
from project.utils.HttpMethod import HttpMethod

#苏州
corpId=99940212
# productName="test111"
effectiveEndTime= "2021-01-31 00:00:00"
effectiveStartTime= "2020-12-26 00:00:00"
effectiveTime="2020-12-26,2025-04-30"
#方案类型是否支持续约（0：是，1：否）
only_renew=1
# 业务类型
productType= 20
#准入条件：是否有人证
modelId=29147
#平台类型
dictPlatformTypeList=["20302"]
# 合作方（客户属性）
partnerType="17502"
# 租金配置：租金
# 实收
factRent= 10000
# 租期
tenancy=10
unitPrice= 10000
deposit=100000
# 费用
money=10000
# 附件
fileName="2020122600000008.jpg"
fileurl="http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122600000008.jpg?Expires=1608974035&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=ZzkPuFwtrr0Um1HQmOCeO1%2FLEeU%3D"
filetype="image/jpeg"

#活动配置rentlist/configs
code= 18701
extend="1"
parentCode= "187"
recycle= "1"
reduceMoney=10000
def test():
    url="/api/v1/webapp/product/create"
    data = {
        "appOnline":True,
        "assessManageFees": money,
        "attachmentList": [
            {
                "name": fileName,
                "ossAttachUrl": fileurl,
                "type": filetype
            }
        ],
        "baseManageFees": money,
        "corpId": corpId,
        "deposit":deposit ,
        "dictPlatformTypeList":dictPlatformTypeList,
        "effectiveEndTime": effectiveEndTime,
        "effectiveStartTime": effectiveStartTime,
        "effectiveTime":effectiveTime,
        "entryCriteria":True,
        "existActivity": True,
        # "firstPayment": 0,
        # "id": 0,
        "manageFees": money,
        "modelId": modelId,
        "onlyRenew":only_renew,
        "partnerType": partnerType,
        "productName": name+"江苏",
        # "productRuleList": [
        #     {
        #         "dictCode": "string",
        #         "minLimit": 0,
        #         "productId": 0,
        #         "productType": productType,
        #         "quantityUnit": "string",
        #         "timeUnit": 0
        #     }
        # ],
        "productType": productType,
        # "remark": "string",
        "rentList": [
            {
        #         "buyoutPrice": 0,
                "configs": [
                    {
                        "code": code,
        #                 "desc": "string",
        #                 "id": 0,
                        "parentCode": parentCode,
        #                 "parentDesc": "string",
        #                 "productId": 0,
                        "recycle":recycle,
                        "reduceMoney": reduceMoney,
        #                 "remark": "string",
        #                 "rentId": 0,
        #                 "sectionMax": 0,
        #                 "sectionMin": 0,
        #                 "sectionUnit": 0,
        #                 "type": 0
                    }
                ],
        #         "extendTenancy": 0,
                "extendTenancyType": False,
                "factRent": factRent,
        #         "service": 0,
                "tenancy": tenancy,
                "unitPrice":unitPrice
            }
        ],
        # "service": 0,
        # "tailPayment": 0,
        # "totalTenancyDuration": 0
    }

    return HttpMethod(url).post(data)

if __name__== '__main__':
    pytest.main(['-s', '-v', 'test_ProductCreate.py'])
