from project.utils.HttpMethod import *
import pytest

'''
产品下架
'''

prodcutId = "598"


def test():
    url = "/api/v1/webapp/product/" + prodcutId
    return HttpMethod(url).delete()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_DeleteProductId.py'])