'''
app产品上下线
'''
import pytest

from project.utils.HttpMethod import *

productId = 860


def test():
    # online="false"
    online = "True"

    url = "/api/v1/webapp/product/app/online"
    data = {
        "online": online,
        "productId": productId
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_OnlineProduct.py'])