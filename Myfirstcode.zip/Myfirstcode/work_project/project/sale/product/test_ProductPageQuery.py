import pytest
from project.utils.HttpMethod import HttpMethod


"""
获取某城市待审批方案列表数据
"""



url = "/api/v1/webapp/product/pageQuery"
corpIds= [99940212]
pageIndex= 1
pageSize= 20
productStatus= 20


def test():
    data={
        "corpIds": corpIds,
        "pageIndex":pageIndex,
        "pageSize": pageSize,
        "productStatus": productStatus
        # startDate:
    }
    return HttpMethod(url).post(data)

if __name__=="__main__":
    pytest.main(['-s','-v','test_ProductPageQuery.py'])