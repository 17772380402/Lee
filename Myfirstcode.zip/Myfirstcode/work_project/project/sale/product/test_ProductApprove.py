import pytest
from project.utils.HttpMethod import HttpMethod

"""
方案审批
"""

approvalType= 1
refId=945
url="/api/v1/webapp/approval/approve"
def test():
    data={
        "approvalType": approvalType,
        "pass":True,
        "refId":refId,
    }
    return HttpMethod(url).post(data)

if __name__ == '__main__':
    pytest.main(['-s','-v','test_ProductApprove.py'])