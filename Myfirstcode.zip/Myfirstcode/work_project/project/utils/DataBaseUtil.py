from sqlalchemy import create_engine, Column, Integer, String, Date
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

# 创建连接
# "mysql://user:password@hostname/dbname?charset=utf8"
# 测试环境
engine = create_engine("mysql://erp:erp@rm-bp1y969moaa0s3dv1do.mysql.rds.aliyuncs.com/erp_st?charset=utf8")
# 生产环境
# engine = create_engine("mysql://zengyouzu:Aa123456@rm-bp1ejnm8qkdyvq3pw1o.mysql.rds.aliyuncs.com/erp?charset=utf8")

# 创建session
DbSession = sessionmaker(bind=engine)
session = DbSession()

# 创建数据库类型
Base = declarative_base()
