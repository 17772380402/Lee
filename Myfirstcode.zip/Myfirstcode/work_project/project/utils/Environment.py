url_pre = "https://st-app.maxima-cars.com"  # 测试环境
# url_pre = "https://app.maxima-cars.com"  # 生产环境
wx_url_pre = "https://st-wx-api.maxima-cars.com"  # 微信小程序
