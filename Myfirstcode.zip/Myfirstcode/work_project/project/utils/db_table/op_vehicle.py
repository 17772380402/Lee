from project.utils.DataBaseUtil import *


class Vehicle(Base):
    __tablename__ = "op_vehicle"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer)
    plate = Column(String(32))
    vin_code = Column(String(32))
    engine_no = Column(String(32))
    vehicle_id = Column(Integer)
    color = Column(String(32))
    dept_id = Column(Integer)
    reg_date = Column(Date)
    owner_name = Column(String(64))
    valid_date = Column(Date)
    certificate_date = Column(Date)
    locked = Column(Integer)
    use_type = Column(String(10))
    tertiary_status = Column(String(10))
    transport_cert = Column(String(10))
    scrap_info = Column(String(128))
    type = Column(String(10))
    property = Column(String(10))
    vehicle_status = Column(String(10))
    od_memter = Column(Integer)
    hev_memter = Column(Integer)
    keyword = Column(String(128))
    diposition_date = Column(String(64))
    diposition_price = Column(Integer)
    diposition_remark = Column(String(256))
    cust_id = Column(Integer)
    cust_name = Column(String(45))
    cust_mobile = Column(String(45))
    cust_keyword = Column(String(256))
    remark = Column(String(256))
    diposition_creator_id = Column(Integer)
    dipostion_gmt_create = Column(String(64))
    dipostion_gmt_modify = Column(String(64))
    status = Column(Integer)
    partner_type = Column(Integer)
    creater_id = Column(Integer)
    gmt_create = Column(String(64))
    gmt_modify = Column(String(64))
    bamboo_car = Column(Integer)

    def __init__(self, tenant_id, plate, vin_code, engine_no, vehicle_id, color, dept_id, reg_date, owner_name,
                 valid_date, certificate_date, locked, use_type, transport_cert, type, property, vehicle_status,
                 od_memter, hev_memter, keyword, status, creater_id, gmt_create):
        self.tenant_id = tenant_id
        self.plate = plate
        self.vin_code = vin_code
        self.engine_no = engine_no
        self.vehicle_id = vehicle_id
        self.color = color
        self.dept_id = dept_id
        self.reg_date = reg_date
        self.owner_name = owner_name
        self.valid_date = valid_date
        self.certificate_date = certificate_date
        self.locked = locked
        self.use_type = use_type
        self.transport_cert = transport_cert
        self.type = type
        self.property = property
        self.vehicle_status = vehicle_status
        self.od_memter = od_memter
        self.hev_memter = hev_memter
        self.keyword = keyword
        self.status = status
        self.creater_id = creater_id
        self.gmt_create = gmt_create



