from project.utils.DataBaseUtil import *


class Customer(Base):
    __tablename__ = "crm_customer"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer)
    cust_name = Column(String(64))
    sex = Column(String(10))
    mobile = Column(String(32))
    source = Column(String(10))
    remark = Column(String(248))
    signing_status = Column(String(45))
    cust_status = Column(String(45))
    old_id = Column(String(45))
    city = Column(String(45))
    age = Column(Integer)
    owner_id = Column(Integer)
    telesales_owner_id = Column(Integer)
    cust_level = Column(String(45))
    native_place = Column(String(64))
    cust_type = Column(String(45))
    id_no = Column(String(45))
    addr = Column(String(128))
    house_addr = Column(String(128))
    education = Column(String(45))
    network_car_lic = Column(Integer)
    cust_no = Column(String(45))
    driver_license_type = Column(String(45))
    cart_date = Column(String(45))
    social_security = Column(Integer)
    introduction_name = Column(String(32))
    introduction_mobile = Column(String(32))
    introduction_status = Column(Integer)
    dept_id = Column(Integer)
    company_name = Column(String(45))
    company_sim_name = Column(String(45))
    business_lic = Column(String(45))
    contact = Column(String(45))
    bank = Column(String(45))
    bank_card_no = Column(String(45))
    InterviewJob = Column(String(64))
    visit_times = Column(Integer)
    call_times = Column(Integer)
    visit_date = Column(Date)
    visit_remark = Column(String(512))
    status = Column(Integer)
    creater_id = Column(Integer)
    gmt_create = Column(String(32))
    gmt_modify = Column(String(32))
    driving_age = Column(Integer)
    contact_telephone = Column(String(20))
    contact_relation = Column(String(20))
    didi_account = Column(String(10))
    criminal_record = Column(Integer)
    major_traffic_acc = Column(Integer)
    residence = Column(Integer)
    secret_number = Column(String(64))
    hand_modify_mobile = Column(Integer)
    unique_mark = Column(String(64))
    sharer_id = Column(Integer)
    channel_type = Column(Integer)
    within_blacklist = Column(Integer)

    def __init__(self, tenant_id, cust_name, sex, mobile, source, remark, signing_status, cust_status, old_id, city,
                 age, owner_id, telesales_owner_id, cust_level, native_place, cust_type, id_no, addr, house_addr,
                 education, network_car_lic, cust_no, driver_license_type, cart_date, social_security,
                 introduction_name, introduction_mobile, introduction_status, dept_id, company_name, company_sim_name,
                 business_lic, contact, bank, bank_card_no, InterviewJob, visit_times, call_times, visit_date,
                 visit_remark, status, creater_id, gmt_create, gmt_modify, driving_age, contact_telephone,
                 contact_relation, didi_account, criminal_record, major_traffic_acc, residence, secret_number,
                 hand_modify_mobile, unique_mark, sharer_id, channel_type, within_blacklist):
        self.tenant_id = tenant_id
        self.cust_name = cust_name
        self.sex = sex
        self.mobile = mobile
        self.source = source
        self.remark = remark
        self.signing_status = signing_status
        self.cust_status = cust_status
        self.old_id = old_id
        self.city = city
        self.age = age
        self.owner_id = owner_id
        self.telesales_owner_id = telesales_owner_id
        self.cust_level = cust_level
        self.native_place = native_place
        self.cust_type = cust_type
        self.id_no = id_no
        self.addr = addr
        self.house_addr = house_addr
        self.education = education
        self.network_car_lic = network_car_lic
        self.cust_no = cust_no
        self.driver_license_type = driver_license_type
        self.cart_date = cart_date
        self.social_security = social_security
        self.introduction_name = introduction_name
        self.introduction_mobile = introduction_mobile
        self.introduction_status = introduction_status
        self.dept_id = dept_id
        self.company_name = company_name
        self.company_sim_name = company_sim_name
        self.business_lic = business_lic
        self.contact = contact
        self.bank = bank
        self.bank_card_no = bank_card_no
        self.InterviewJob = InterviewJob
        self.visit_times = visit_times
        self.call_times = call_times
        self.visit_date = visit_date
        self.visit_remark = visit_remark
        self.status = status
        self.creater_id = creater_id
        self.gmt_create = gmt_create
        self.gmt_modify = gmt_modify
        self.driving_age = driving_age
        self.contact_telephone = contact_telephone
        self.contact_relation = contact_relation
        self.didi_account = didi_account
        self.criminal_record = criminal_record
        self.major_traffic_acc = major_traffic_acc
        self.residence = residence
        self.secret_number = secret_number
        self.hand_modify_mobile = hand_modify_mobile
        self.unique_mark = unique_mark
        self.sharer_id = sharer_id
        self.channel_type = channel_type
        self.within_blacklist = within_blacklist
