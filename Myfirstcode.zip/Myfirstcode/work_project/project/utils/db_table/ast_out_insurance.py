from project.utils.DataBaseUtil import *


class OutInsurance(Base):
    __tablename__ = "ast_out_insurance"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer)
    code = Column(String(32))
    out_insurance_date = Column(Date)
    vehicle_id = Column(Integer)
    corp_id = Column(Integer)
    contract_id = Column(Integer)
    report_code = Column(String(64))
    area = Column(String(64))
    responsibility_type = Column(String(8))
    accident_type = Column(String(8))
    person = Column(String(32))
    mobile = Column(String(11))
    vehicle_fee = Column(Integer)
    total_fee = Column(Integer)
    label = Column(String(8))
    creater_id = Column(Integer)
    creater_name = Column(String(32))
    remark = Column(String(200))
    ding_remark = Column(String(200))
    closing_status = Column(Integer)
    process_status = Column(String(16))
    status = Column(Integer)
    gmt_create = Column(String(32))
    gmt_modify = Column(String(32))

    def __init__(self, tenant_id, code, out_insurance_date, vehicle_id, corp_id, contract_id, report_code, area,
                 responsibility_type, accident_type, person, mobile, vehicle_fee, total_fee, label, creater_id,
                 creater_name, remark, ding_remark, closing_status, process_status, status, gmt_create, gmt_modify, ):
        self.tenant_id = tenant_id
        self.code = code
        self.out_insurance_date = out_insurance_date
        self.vehicle_id = vehicle_id
        self.corp_id = corp_id
        self.contract_id = contract_id
        self.report_code = report_code
        self.area = area
        self.responsibility_type = responsibility_type
        self.accident_type = accident_type
        self.person = person
        self.mobile = mobile
        self.vehicle_fee = vehicle_fee
        self.total_fee = total_fee
        self.label = label
        self.creater_id = creater_id
        self.creater_name = creater_name
        self.remark = remark
        self.ding_remark = ding_remark
        self.closing_status = closing_status
        self.process_status = process_status
        self.status = status
        self.gmt_create = gmt_create
        self.gmt_modify = gmt_modify
