from project.utils.DataBaseUtil import *


class Attachment(Base):
    __tablename__ = "sys_attachments"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer)
    ref_id = Column(Integer)
    ref_type = Column(String(32))
    sub_type = Column(String(64))
    file_name = Column(String(32))
    file_type = Column(String(32))
    file_url = Column(String(32))
    bucket = Column(String(32))
    status = Column(Integer)
    gmt_create = Column(String(32))
    gmt_modify = Column(String(32))

    def __init__(self, tenant_id, ref_id, ref_type, sub_type, file_name, file_type, file_url, bucket, status,
                 gmt_create, gmt_modify):
        self.tenant_id = tenant_id
        self.ref_id = ref_id
        self.ref_type = ref_type
        self.sub_type = sub_type
        self.file_name = file_name
        self.file_type = file_type
        self.file_url = file_url
        self.bucket = bucket
        self.status = status
        self.gmt_create = gmt_create
        self.gmt_modify = gmt_modify
