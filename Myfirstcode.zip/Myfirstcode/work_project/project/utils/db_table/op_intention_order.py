from project.utils.DataBaseUtil import *

class IntentionOrder(Base):
    __tablename__ = "op_intention_order"
    id= Column(Integer, primary_key=True)
    reservation_id= Column(Integer)
    order_no=Column(String(64))
    cust_id=Column(Integer)
    cust_name=Column(String(64))
    channel_name=Column(String(100))
    channel_id=Column(Integer)
    mobile=Column(String(11))
    id_no=Column(String(64))
    source=Column(String(10))
    product_id=Column(Integer)
    rent_id=Column(Integer)
    activity_id=Column(Integer)
    product_type=Column(Integer)
    product_number=Column(Integer)
    product_name=Column(String(64))
    model_id=Column(Integer)
    model_name=Column(String(64))
    unit_price=Column(Integer)
    delivery_time=Column(Date)
    user_id=Column(Integer)
    user_name=Column(String(64))
    dept_id=Column(Integer)
    introduce_type=Column(String(20))
    introduce_name=Column(String(64))
    introduce_mobile=Column(String(11))
    earnest_money=Column(Integer)
    pay_time=Column(Integer)
    pay_status=Column(Integer)
    vehicle_image=Column(String(521))
    cancel_date=Column(Date)
    bill_id=Column(Integer)
    type=Column(Integer)
    drip=Column(String(45))
    reason=Column(String(16))
    remarks=Column(String(512))
    order_status=Column(Integer)
    network_car_lic=Column(Integer)
    is_seller2=Column(Integer)
    is_seller=Column(Integer)
    status=Column(Integer)
    ref_contract_id=Column(Integer)
    ref_contract_no=Column(String(32))
    operate_source=Column(String(32))
    creater_id=Column(Integer)
    gmt_create=Column(Integer)
    gmt_modify=Column(Integer)

    def __init__(self,reservation_id,order_no,cust_id,cust_name, channel_name,channel_id,mobile, id_no,
                 source ,product_id,rent_id , activity_id,product_type,product_number,product_name ,model_id,
                 model_name,unit_price,delivery_time, user_id,user_name,dept_id,introduce_type,introduce_name ,
                 introduce_mobile,earnest_money,pay_time,pay_status, vehicle_image,cancel_date, bill_id,type,
                 drip,reason,remarks,order_status,network_car_lic ,is_seller2 ,is_seller , status,
                 ref_contract_id,ref_contract_no,operate_source,creater_id,gmt_create,gmt_modify):


        self.id = id
        self.reservation_id = reservation_id
        self.order_no = order_no
        self.cust_id = cust_id
        self.cust_name = cust_name
        self.channel_name = channel_name
        self.channel_id = channel_id
        self.mobile = mobile
        self.id_no = id_no
        self.source = source
        self.product_id = product_id
        self.rent_id = rent_id
        self.activity_id = activity_id
        self.product_type = product_type
        self.product_number = product_number
        self.product_name = product_name
        self.model_id = model_id
        self.model_name = model_name
        self.unit_price = unit_price
        self.delivery_time = delivery_time
        self.user_id = user_id
        self.user_name = user_name
        self.dept_id = dept_id
        self.introduce_type = introduce_type
        self.introduce_name = introduce_name
        self.introduce_mobile =introduce_mobile
        self. earnest_money = earnest_money
        self.pay_time =pay_time
        self. pay_status =pay_status
        self. vehicle_image =vehicle_image
        self. cancel_date = cancel_date
        self.bill_id =bill_id
        self. type = type
        self.drip = drip
        self.reason = reason
        self.remarks =remarks
        self. order_status = order_status
        self.network_car_lic = network_car_lic
        self.is_seller2 = is_seller2
        self.is_seller = is_seller
        self.status = status
        self.ref_contract_id = ref_contract_id
        self.ref_contract_no = ref_contract_no
        self.operate_source = operate_source
        self.creater_id = creater_id
        self.gmt_create = gmt_create
        self.gmt_modify = gmt_modify
