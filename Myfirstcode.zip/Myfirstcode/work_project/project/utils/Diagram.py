import matplotlib.pyplot as plt
import numpy as np

# 重载字体，解决中文乱码
plt.rcParams['font.serif'] = ['SimHei']
plt.rcParams['font.sans-serif'] = ['SimHei']


class Diagram:
    # 饼图
    def pie(self, labels, sizes, explode):
        plt.pie(sizes, radius=1, explode=explode, autopct='%1.1f%%', shadow=False,
                startangle=45)
        plt.pie([1], radius=0.8, colors='white')
        plt.legend(labels, bbox_to_anchor=(1, 1), loc='best', borderaxespad=0)
        plt.show()

    # 平面坐标图
    def plot(self, xlabel, ylabel, x, y):
        plt.plot(x, y)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.show()

    # 直方图
    def bar(self, xlabel, ylabel, x, y):
        plt.bar(x, y, align='center')
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.show()

