from faker import Faker
import time, datetime

f = Faker(locale='zh_CN')

dateStr1 = time.strftime('%Y-%m-%dT00:00:00.000Z')
dateStr2 = time.strftime('%Y-%m-%dT00:00:00+08:00')
name = f.name()
mobile = f.phone_number()
email = f.email()
idNo = f.ssn()
addr = f.address()
randomNum = f.random_number(5)
nowDate = (datetime.datetime.now() + datetime.timedelta(days=0)).strftime('%Y-%m-%d')
pastDate = (datetime.datetime.now() + datetime.timedelta(days=-365)).strftime('%Y-%m-%d')
futureDate = (datetime.datetime.now() + datetime.timedelta(days=365)).strftime('%Y-%m-%d')
companyName = f.company()
cost = f.random_int(0, 10000) * 100
