from faker import Faker
import random

f = Faker(locale='zh_CN')


# 故障类型 15301: 电控/发动机, 15302: 传动系统, 15303: 转向系统, 15304: 制动系统, 15305: 行驶系统
# 15306: 车身系统, 15307: 电气系统, 15308: 其他, 15309: 空调系统, 15310: 散热系统, 15311: 照明系统
def getFaultType():
    faultType = ["15301", "15302", "15303", "15304", "15305", "15306", "15307", "15308", "15309", "15310", "15311"]
    randomFaultType = random.choice(faultType)
    return randomFaultType


faultType = getFaultType()


# 故障处理方式 15401: 不处理, 15402: 拖车, 15403: 修车, 15404: 拖车及修车
def getProcessType():
    processType = [15401, 15402, 15403, 15404]
    randomProcessType = random.choice(processType)
    return randomProcessType


processType = getProcessType()


# 故障费用承担方 15501: 公司, 15502: 司机, 15503: 保险公司, 15504: 4S店, 15505: 其他
def getCostHolder():
    costHolder = [15501, 15502, 15503, 15504, 15505]
    randomCostHolder = random.choice(costHolder)
    return randomCostHolder


costHolder = getCostHolder()
