from faker import Faker
import random
import datetime

f = Faker(locale='zh_CN')


# 办理人 14001: 公司, 14002: 个人
def getCostHolder():
    costHolder = [
        "14001",
        # "14002"
    ]
    randomCostHolder = random.choice(costHolder)
    return randomCostHolder


costHolder = getCostHolder()
validDate = (datetime.datetime.now() + datetime.timedelta(days=30)).strftime('%Y-%m-%dT00:00:00+08:00')


# 承担方 13901: 公司, 13902: 个人
def getTransactorType():
    transactorType = [
        "13901",
        # "13902"
    ]
    randomTransactorType = random.choice(transactorType)
    return randomTransactorType


transactorType = getTransactorType()
