from faker import Faker
import random

f = Faker(locale='zh_CN')


# 所在区
def getAreaName():
    areaName = ["黄浦区", "卢湾区", "徐汇区", "长宁区", "静安区", "普陀区", "闸北区", "虹口区", "杨浦区",
                "闵行区", "宝山区", "嘉定区", "浦东新区", "金山区","松江区", "青浦区", "南汇区", "奉贤区", "崇明县"]
    randomAreaName = random.choice(areaName)
    return randomAreaName


areaName = getAreaName()


# 银行
def getBankName():
    bankName = ["中国工商银行", "招商银行", "中国建设银行", "中国银行", "交通银行", "平安银行",
                "农商银行", "中国农业银行", "中国民生银行", "中国光大银行", "中信银行", "兴业银行",
                "上海浦东发展银行", "中国人民银行", "华夏银行", "中国邮政储蓄银行", "上海银行"]
    randomBankName = random.choice(bankName)
    return randomBankName


bankName = getBankName()
bankCard = f.bban()
