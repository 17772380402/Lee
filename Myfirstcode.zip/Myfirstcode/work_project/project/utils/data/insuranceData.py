from faker import Faker
import random
import time

f = Faker(locale='zh_CN')


# 保险公司
def getInsuranceCompany():
    insuranceCompany = ["深圳平安", "宁波平安", "厦门人保", "杭州人保", "广州人保", "东莞人保",
                        "深圳中银", "广州中银", "厦门阳光", "重庆锦泰", "永诚保险", "长沙中华联合", "苏州太平洋", "深圳太平洋",
                        "深圳人保", "重庆人保", "永安", "厦门平安", "佛山平安", "武汉人保", "上海太平", "深圳太平", "测试保险"]
    randomInsuranceCompany = random.choice(insuranceCompany)
    return randomInsuranceCompany


insuranceCompany = getInsuranceCompany()


# 投保人员 13701:司机, 13702:公司
def getInsuranceIdentity():
    insuranceIdentity = ["13701", "13702"]
    randomInsuranceIdentity = random.choice(insuranceIdentity)
    return randomInsuranceIdentity


insuranceIdentity = getInsuranceIdentity()


# 事故类型 16101:单方, 16102:双方, 16103:多方
def getAccidentType():
    accidentType = ["16101", "16102", "16103"]
    randomAccidentType = random.choice(accidentType)
    return randomAccidentType


accidentType = getAccidentType()
outInsuranceCode = "CX" + time.strftime('%Y%m%d') + str(f.random_number(4))
outInsuranceDate = time.strftime('%Y-%m-%d')


# 责任类型 16001:全部责任, 16002:主要责任, 16003:同等责任, 16004:次要责任, 16005:无责任, 16006:待定
def getResponsibilityType():
    responsibilityType = ["16001", "16002", "16003", "16004", "16005"]
    randomResponsibilityType = random.choice(responsibilityType)
    return randomResponsibilityType


responsibilityType = getResponsibilityType()
