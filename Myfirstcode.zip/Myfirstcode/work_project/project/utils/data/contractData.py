from faker import Faker
import random
import time

f = Faker(locale='zh_CN')

contractCode = 'G{}'.format(time.strftime('%Y%m%d')) + str(f.random_number(4))

collectRentDay = int(time.strftime('%d'))


# 延期项目 20401: 维修, 20402: 脱保养, 20403: 车损, 20404: 年检, 20405: 扣车, 20406: 事故罚款
# 20407: 无责事故（最高7天）, 20408: 平台类, 20409: 内部人员业务差错, 20410: 其他类, 20411: 暂退, 20412: 方案内延期
def getReduceProject():
    reduceProject = ["20401", "20402", "20403", "20404", "20405", "20406", "20407", "20408", "20409", "20410", "20411",
                     "20412", ]
    randomReduceProject = random.choice(reduceProject)
    return randomReduceProject


reduceProject = getReduceProject()


# 平台方 19301: 线下自营, 19302: 美团, 19303: 小桔, 19304: 全桔
def getPlatform():
    platform = ["19301", "19302", "19303", "19304"]
    randomPlatform = random.choice(platform)
    return randomPlatform


platform = getPlatform()

startDate = time.strftime('%Y-%m-%dT00:00:00+08:00')

endDate = time.strftime('%Y-%m-%dT00:00:00+08:00')


# 出行平台 20301: 滴滴, 20302: 美团, 20303: 国泰, 20304: 全在, 20305: 携华, 20306: 其它平台,
# 20307: 900出行, 20308: 恒好用车, 20309: 及时用车, 20310: 曹操, 20311: 前行, 20313: 同港出行
def getTravelPlatform():
    travelPlatform = ["20301", "20302", "20303", "20304", "20305", "20306", "20307", "20308", "20309", "20310", "20311",
                      "20313"]
    randomTravelPlatform = random.choice(travelPlatform)
    return randomTravelPlatform


travelPlatform = getTravelPlatform()


# 支付方式
def getPaymentType():
    paymentType = ["银行卡", "现金", "pos机", "线下微信", "线下支付宝", "合同转账", "意向金转入",
                   "滴滴代扣", "线下支付", "付款转移", "对公转移", "对公微信", "对公支付宝", "小桔", "全桔"]
    randomPaymentType = random.choice(paymentType)
    return randomPaymentType


paymentType = getPaymentType()
