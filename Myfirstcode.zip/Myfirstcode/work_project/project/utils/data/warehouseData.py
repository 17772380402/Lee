from faker import Faker
import random

f = Faker(locale='zh_CN')


# 所在区
def getAreasName():
    areasName = ["黄浦区", "卢湾区", "徐汇区", "长宁区", "静安区", "普陀区", "闸北区", "虹口区", "杨浦区", "闵行区", "宝山区", "嘉定区", "浦东新区", "金山区",
                 "松江区", "青浦区", "南汇区", "奉贤区", "崇明县"]
    randomAreasName = random.choice(areasName)
    return randomAreasName


areasName = getAreasName()
