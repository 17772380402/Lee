from faker import Faker
import random

f = Faker(locale='zh_CN')


# 对公银行 19601: 中国工商银行, 19602: 招商银行, 19603: 中国建设银行, 19604: 中国银行, 19605: 交通银行, 19606: 平安银行, 19607: 农商银行,
# 19608: 中国农业银行, 19609: 中国民生银行, 19610: 中国光大银行, 19611: 中信银行, 19612: 兴业银行, 19613: 上海浦东发展银行, 19614: 中国人民银行
def getBankCode():
    bankCode = ["19601", "19602", "19603", "19604", "19605", "19606", "19607", "19608", "19609", "19610", "19611",
                "19612", "19613", "19614", ]
    randomBankCode = random.choice(bankCode)
    return randomBankCode


bankCode = getBankCode()
bankNumber = f.bban()


# 大客户来源 19501: 渠道商, 19502: 代管理, 19503: 兜底
def getPartnerSource():
    partnerSource = ["19501", "19502", "19503"]
    randomPartnerSource = random.choice(partnerSource)
    return randomPartnerSource


partnerSource = getPartnerSource()

