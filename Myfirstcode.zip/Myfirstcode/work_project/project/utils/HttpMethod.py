import requests
import json

from project.utils import Token
from project.utils import Environment


class HttpMethod(object):

    def __init__(self, url):
        self.url = url

    def get(self):
        headers = {
            "token": Token.token
        }
        r = requests.get(Environment.url_pre + self.url, headers=headers)
        r_dict = json.loads(r.text)
        r_dict_data = r_dict.get('data')
        if r_dict.get('success') == True:
            print('{}请求成功'.format('get'))
            if r_dict_data is not None:
                print('响应结果:')
                print(json.dumps(r_dict_data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
            return r_dict_data
        else:
            print('请求失败！')
            print('响应结果:')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    def post(self, data):
        headers = {
            "token": Token.token
        }
        r = requests.post(Environment.url_pre + self.url, headers=headers, json=data)
        r_dict = json.loads(r.text)
        r_dict_data = r_dict.get('data')
        if len(data) != 0:
            print('请求参数:')
            print(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
        if r_dict.get('success') == True:
            print('{}请求成功'.format('post'))
            if r_dict_data is not None:
                print('响应结果:')
                print(json.dumps(r_dict_data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
            return r_dict_data
        else:
            print('请求失败！')
            print('响应结果:')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    def delete(self):
        headers = {
            "token": Token.token
        }
        r = requests.delete(Environment.url_pre + self.url, headers=headers)
        r_dict = json.loads(r.text)
        if r_dict.get('success') == True:
            print('{}请求成功'.format('delete'))
        else:
            print('请求失败！')
            print('响应结果：')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    def put(self, data):
        headers = {
            "token": Token.token
        }
        r = requests.put(Environment.url_pre + self.url, headers=headers, json=data)
        r_dict = json.loads(r.text)
        r_dict_data = r_dict.get('data')
        if len(data) != 0:
            print('请求参数:')
            print(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
        if r_dict.get('success') == True:
            print('{}请求成功'.format('put'))
            if r_dict_data is not None:
                print('响应结果:')
                print(json.dumps(r_dict_data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
            return r_dict_data
        else:
            print('请求失败！')
            print('响应结果:')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    # wx端

    def get1(self):
        headers = {
            "token": Token.wx_token
        }
        r = requests.get(Environment.wx_url_pre + self.url, headers=headers)
        r_dict = json.loads(r.text)
        r_dict_data = r_dict.get('data')
        if r_dict.get('success') == True:
            print('{}请求成功'.format('get'))
            if r_dict_data is not None:
                print('响应结果:')
                print(json.dumps(r_dict_data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
            return r_dict_data
        else:
            print('请求失败！')
            print('响应结果:')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    def post1(self, data):
        headers = {
            "token": Token.wx_token
        }
        r = requests.post(Environment.wx_url_pre + self.url, headers=headers, json=data)
        r_dict = json.loads(r.text)
        r_dict_data = r_dict.get('data')
        if len(data) != 0:
            print('请求参数:')
            print(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
        if r_dict.get('success') == True:
            print('{}请求成功'.format('post'))
            if r_dict_data is not None:
                print('响应结果:')
                print(json.dumps(r_dict_data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
            return r_dict_data
        else:
            print('请求失败！')
            print('响应结果:')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    def delete1(self):
        headers = {
            "token": Token.wx_token
        }
        r = requests.delete(Environment.wx_url_pre + self.url, headers=headers)
        r_dict = json.loads(r.text)
        if r_dict.get('success') == True:
            print('{}请求成功'.format('delete'))
        else:
            print('请求失败！')
            print('响应结果：')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))

    def put1(self, data):
        headers = {
            "token": Token.wx_token
        }
        r = requests.put(Environment.wx_url_pre + self.url, headers=headers, json=data)
        r_dict = json.loads(r.text)
        r_dict_data = r_dict.get('data')
        if len(data) != 0:
            print('请求参数:')
            print(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
        if r_dict.get('success') == True:
            print('{}请求成功'.format('put'))
            if r_dict_data is not None:
                print('响应结果:')
                print(json.dumps(r_dict_data, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
            return r_dict_data
        else:
            print('请求失败！')
            print('响应结果:')
            print(json.dumps(r_dict, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': ')))
