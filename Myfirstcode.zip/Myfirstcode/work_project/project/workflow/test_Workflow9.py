import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.sale.customer import test_AddCustomer, test_TransferCustomer
from project.property.vehicle import test_DispatchVehicle, test_AddVehicle
from project.operation.contract import test_AddContract, test_QueryAuditList, test_AuditContract, \
    test_QueryContractPeriodBill, test_ContractPayment
from project.property.insurance import test_ReturnVehicle, test_CloseInsuranceAndConfirm, test_CloseInsuranceAndSave, \
    test_AscertainLoss, test_Repair, test_AddOutInsurance, test_SendRepair, test_AddInsurance, test_SubmitOutInsurance
from project.property.fault import test_AddMaintain
from project.property.inspection import test_AddInspection
from project.utils.DataBaseUtil import *
from project.utils.db_table import op_vehicle, sys_attachments
import pytest
import time, datetime


# 新增客户-转移客户给他人-新增车辆-新增保单-发车-新增合同-查询待审批合同列表-审批合同-查询合同租期账单-平账-
# 新增保养-新增年检登记-新增出险-定损-送修-维修-取车-确认结案-保存结案资料-提交结案审核
def test():
    result = test_AddCustomer.test()
    test_TransferCustomer.custId = result.get('id')
    test_TransferCustomer.test()
    result1 = test_AddVehicle.test()
    test_AddInsurance.vehicleId = result1.get('id')
    test_AddInsurance.test1()
    test_AddInsurance.test2()
    test_DispatchVehicle.id = result1.get('id')
    test_DispatchVehicle.test()
    session.query(op_vehicle.Vehicle).filter_by(id=result1.get('id')).update({'dept_id': 99940212})
    session.commit()
    test_AddContract.custId = result.get('id')
    test_AddContract.custName = result.get('custName')
    # test_AddContract.idNo = result.get('idNo')
    test_AddContract.mobile = result.get('mobile')
    test_AddContract.vehicleId = result1.get('id')
    test_AddContract.vehiclePlate = result1.get('plate')
    test_AddContract.engineNo = result1.get('engineNo')
    test_AddContract.vin = result1.get('vinCode')
    result2 = test_AddContract.test()
    test_QueryAuditList.contractCode = result2.get('contractCode')
    result3 = test_QueryAuditList.test()
    test_AuditContract.id = result3.get('list')[0].get('id')
    test_AuditContract.test()
    time.sleep(1)  # 审批有延迟需要休眠时间缓冲
    test_QueryContractPeriodBill.contractId = result2.get('id')
    result4 = test_QueryContractPeriodBill.test()
    test_ContractPayment.contractId = result2.get('id')
    test_ContractPayment.periodId = result4.get('list')[0].get('id')
    test_ContractPayment.amount = result4.get('list')[0].get('unpaid')
    test_ContractPayment.test()
    test_AddMaintain.vehicleId = result1.get('id')
    test_AddMaintain.test()
    test_AddInspection.vehicleId = result1.get('id')
    test_AddInspection.test()
    test_AddOutInsurance.vehicleId = result1.get('id')
    result5 = test_AddOutInsurance.test()
    test_AscertainLoss.mobile = result5.get('mobile')
    test_AscertainLoss.name = result5.get('person')
    test_AscertainLoss.outInsuranceId = result5.get('id')
    test_AscertainLoss.plate = result1.get('plate')
    test_AscertainLoss.vehicleId = result1.get('id')
    test_AscertainLoss.test()
    test_SendRepair.faultId = result5.get('id')
    test_SendRepair.source = 1
    test_SendRepair.test()
    test_Repair.faultId = result5.get('id')
    test_Repair.source = 1
    test_Repair.test()
    test_ReturnVehicle.faultId = result5.get('id')
    test_ReturnVehicle.personName = result5.get('person')
    test_ReturnVehicle.source = 1
    test_ReturnVehicle.test()
    test_CloseInsuranceAndConfirm.id = result5.get('id')
    test_CloseInsuranceAndConfirm.test()
    # 经测试，手动插数据到附件表后需要更新一次ref_id字段才能被接口识别
    add_attachment = sys_attachments.Attachment(
        10000, result5.get('id'), "DANGER", "INFORMATION_DINGDING",
        "2020112400000013.jpg", "jpg", "2020112400000013.jpg",
        "maxima-file-staging", 1,
        (datetime.datetime.now() + datetime.timedelta(days=0)).strftime(
            '%Y-%m-%d %H:%M:%S'), ""
    )
    session.add(add_attachment)
    session.query(sys_attachments.Attachment).filter_by(ref_id=result5.get('id')).update({'ref_id': 0})
    session.query(sys_attachments.Attachment).filter_by(ref_id=0).update({'ref_id': result5.get('id')})
    session.commit()
    test_CloseInsuranceAndSave.outInsuranceId = result5.get('id')
    test_CloseInsuranceAndSave.test()
    # test_SubmitOutInsurance.id = result5.get('id')
    # test_SubmitOutInsurance.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow9.py'])
