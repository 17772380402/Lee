import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.property.vehicle import test_DispatchVehicle, test_AddVehicle
from project.property.insurance import test_ReturnVehicle, test_CloseInsuranceAndConfirm, test_CloseInsuranceAndSave, \
    test_AscertainLoss, test_Repair, test_AddOutInsurance, test_SendRepair, test_AddInsurance, test_SubmitOutInsurance
import datetime
from project.utils.DataBaseUtil import *
from project.utils.db_table import sys_attachments
import pytest


# 新增车辆-新增保单-发车-新增出险-定损-送修-维修-取车-确认结案-保存结案资料-提交结案审核
def test():
    result = test_AddVehicle.test()
    test_AddInsurance.vehicleId = result.get('id')
    test_AddInsurance.test1()
    test_AddInsurance.test2()
    test_DispatchVehicle.id = result.get('id')
    test_DispatchVehicle.test()
    test_AddOutInsurance.vehicleId = result.get('id')
    result1 = test_AddOutInsurance.test()
    test_AscertainLoss.mobile = result1.get('mobile')
    test_AscertainLoss.name = result1.get('person')
    test_AscertainLoss.outInsuranceId = result1.get('id')
    test_AscertainLoss.plate = result.get('plate')
    test_AscertainLoss.vehicleId = result.get('id')
    test_AscertainLoss.test()
    test_SendRepair.faultId = result1.get('id')
    test_SendRepair.source = 1
    test_SendRepair.test()
    test_Repair.faultId = result1.get('id')
    test_Repair.source = 1
    test_Repair.test()
    test_ReturnVehicle.faultId = result1.get('id')
    test_ReturnVehicle.personName = result1.get('person')
    test_ReturnVehicle.source = 1
    test_ReturnVehicle.test()
    test_CloseInsuranceAndConfirm.id = result1.get('id')
    test_CloseInsuranceAndConfirm.test()
    # 经测试，手动插数据到附件表后需要更新一次ref_id字段才能被接口识别
    # (如下代码落表字段取这条业务的outInsuranceId，更新为0再重新更新为正确id)，具体原因不明
    add_attachment = sys_attachments.Attachment(
        10000, result.get('id'), "DANGER", "INFORMATION_DINGDING",
        "2020112400000013.jpg", "jpg", "2020112400000013.jpg",
        "maxima-file-staging", 1,
        (datetime.datetime.now() + datetime.timedelta(days=0)).strftime(
            '%Y-%m-%d %H:%M:%S'), ""
    )
    session.add(add_attachment)
    session.query(sys_attachments.Attachment).filter_by(ref_id=result1.get('id')).update({'ref_id': 0})
    session.query(sys_attachments.Attachment).filter_by(ref_id=0).update({'ref_id': result1.get('id')})
    session.commit()
    test_CloseInsuranceAndSave.outInsuranceId = result1.get('id')
    test_CloseInsuranceAndSave.test()
    # test_SubmitOutInsurance.id = result1.get('id')
    # test_SubmitOutInsurance.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow3.py'])
