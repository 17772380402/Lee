import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.sale.customer import test_AddCustomer, test_QueryCustomerById, test_TransferCustomerToSea, \
    test_QueryMyTransferCustomer, test_TransferCustomer, test_TransferCustomerToMyself
import pytest


# 新增客户-转移客户给公海-转移客户给自己-转移客户给他人-id查询客户
def test():
    result = test_AddCustomer.test()
    test_TransferCustomerToSea.id = result.get('id')
    test_TransferCustomerToSea.test()
    # test_TransferCustomerToMyself.id = result.get('id')
    # test_TransferCustomerToMyself.test()
    test_TransferCustomer.custId = result.get('id')
    test_TransferCustomer.test()
    test_QueryCustomerById.id = result.get('id')
    test_QueryCustomerById.test()
    # test_QueryMyTransferCustomer.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow2.py'])
