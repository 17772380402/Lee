import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.sale.customer import test_AddCustomer, test_TransferCustomer
from project.property.insurance import test_AddInsurance
from project.property.vehicle import test_DispatchVehicle, test_AddVehicle
from project.operation.contract import test_AddContract, test_QueryAuditList, test_AuditContract, \
    test_QueryContractPeriodBill, test_ContractPayment
from project.utils.DataBaseUtil import *
from project.utils.db_table import op_vehicle
import pytest
import time


# 新增客户-转移客户给他人-新增车辆-新增保单-发车-新增合同-查询待审批合同列表-审批合同-查询合同租期账单-平账
def test():
    result = test_AddCustomer.test()
    test_TransferCustomer.custId = result.get('id')
    test_TransferCustomer.test()
    result1 = test_AddVehicle.test()
    test_AddInsurance.vehicleId = result1.get('id')
    test_AddInsurance.test1()
    test_AddInsurance.test2()
    test_DispatchVehicle.id = result1.get('id')
    test_DispatchVehicle.test()
    session.query(op_vehicle.Vehicle).filter_by(id=result1.get('id')).update({'dept_id': 99940212})
    session.commit()
    test_AddContract.custId = result.get('id')
    test_AddContract.custName = result.get('custName')
    # test_AddContract.idNo = result.get('idNo')
    test_AddContract.mobile = result.get('mobile')
    test_AddContract.vehicleId = result1.get('id')
    test_AddContract.vehiclePlate = result1.get('plate')
    test_AddContract.engineNo = result1.get('engineNo')
    test_AddContract.vin = result1.get('vinCode')
    result2 = test_AddContract.test()
    test_QueryAuditList.contractCode = result2.get('contractCode')
    result3 = test_QueryAuditList.test()
    test_AuditContract.id = result3.get('list')[0].get('id')
    test_AuditContract.test()
    time.sleep(1)  # 审批有延迟需要休眠时间缓冲
    test_QueryContractPeriodBill.contractId = result2.get('id')
    result4 = test_QueryContractPeriodBill.test()
    test_ContractPayment.contractId = result2.get('id')
    test_ContractPayment.periodId = result4.get('list')[0].get('id')
    test_ContractPayment.amount = result4.get('list')[0].get('unpaid')
    test_ContractPayment.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow6.py'])
