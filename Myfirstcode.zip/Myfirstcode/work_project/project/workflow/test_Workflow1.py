import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.property.insurance import test_AddInsurance
from project.property.vehicle import test_DispatchVehicle, test_AddVehicle
from project.utils.DataBaseUtil import *
from project.utils.db_table import op_vehicle
import pytest


# 新增车辆-新增保单-发车
def test():
    result = test_AddVehicle.test()
    test_AddInsurance.vehicleId = result.get('id')
    test_AddInsurance.test1()
    test_AddInsurance.test2()
    test_DispatchVehicle.id = result.get('id')
    test_DispatchVehicle.test()
    # 改车辆dept_id至对应公司以匹配当地的销售方案
    # session.query(op_vehicle.Vehicle).filter_by(id=result.get('id')).update({'dept_id': 99940212})
    # session.commit()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow1.py'])
