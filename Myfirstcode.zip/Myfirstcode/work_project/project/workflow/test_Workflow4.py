import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.property.vehicle import test_DispatchVehicle, test_AddVehicle
from project.property.insurance import test_ReturnVehicle, test_Repair, test_SendRepair, test_AddInsurance
from project.property.fault import test_AddFault, test_AddTrailer
import pytest
from project.utils.DataBaseUtil import *
from project.utils.db_table import op_vehicle


# 新增车辆-新增保单-发车-新增故障(拖车及修车)-拖车-送修-维修-取车
def test():
    result = test_AddVehicle.test()
    s = session.query(op_vehicle.Vehicle).filter_by(plate=result.get('plate')).all()
    for item in s:
        test_AddInsurance.vehicleId = item.id
        test_AddInsurance.test1()
        test_AddInsurance.test2()
        test_DispatchVehicle.id = item.id
        test_DispatchVehicle.test()
        test_AddFault.vehicleId = item.id
        result = test_AddFault.test()
        test_AddTrailer.faultId = result.get('id')
        test_AddTrailer.test()
        test_SendRepair.faultId = result.get('id')
        test_SendRepair.test()
        test_Repair.faultId = result.get('id')
        test_Repair.test()
        test_ReturnVehicle.faultId = result.get('id')
        test_ReturnVehicle.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow4.py'])
