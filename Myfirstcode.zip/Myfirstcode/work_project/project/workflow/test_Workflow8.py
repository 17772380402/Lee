import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.sale.policy import test_AddSalesPolicy
from project.sale.policy import test_PolicyApprove
import pytest


# Tsp新增策略—审批策略

def test():
    result = test_AddSalesPolicy.test()
    test_PolicyApprove.refId = result.get('id')
    test_PolicyApprove.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow8.py'])
