import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.property.insurance import test_AddInsurance
from project.property.vehicle import test_DispatchVehicle, test_AddVehicle
from project.property.fault import test_AddMaintain
from project.property.inspection import test_AddInspection
import pytest

# 新增车辆-新增保单-发车-新增保养-新增年检登记
def test():
    result = test_AddVehicle.test()
    test_AddInsurance.vehicleId = result.get('id')
    test_AddInsurance.test1()
    test_AddInsurance.test2()
    test_DispatchVehicle.id = result.get('id')
    test_DispatchVehicle.test()
    test_AddMaintain.vehicleId = result.get('id')
    test_AddMaintain.test()
    test_AddInspection.vehicleId = result.get('id')
    test_AddInspection.test()


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow5.py'])
