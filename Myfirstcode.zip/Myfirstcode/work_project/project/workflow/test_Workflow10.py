
import sys
import os

# 部署到jenkins的项目目录在引用自定义模块时需要重定向
currentPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(currentPath)[0]
sys.path.append(os.path.split(rootPath)[0])

from project.sale.intentionOrder import test_AddIntentionOrder
from project.sale.intentionOrder import test_QueryIntentionOrderById
from project.sale.intentionOrder import test_IntentionOrderPayment
from project.sale.intentionOrder import test_IntentionOrderContract
import pytest

# 小程序创建意向订单——查询意向单列表--后台意向单确认收款——意向单跳转生成关联id合同

def test():
    result=test_AddIntentionOrder.test()
    print(result)
    test_QueryIntentionOrderById.id = result
    result1 = test_QueryIntentionOrderById.test()
    test_IntentionOrderPayment.amount=result1.get('earnestMoney')
    test_IntentionOrderPayment.intentionId = result1.get('id')
    test_IntentionOrderContract.cust_Id = result1.get('cust_id')
    test_IntentionOrderContract.custName = result1.get('custName')
    test_IntentionOrderContract.idNo = result1.get('idNo')
    test_IntentionOrderContract.mobile = result1.get('mobile')
    test_IntentionOrderContract.modelId = result1.get('modelId')
    test_IntentionOrderContract.productId = result1.get('productId')
    test_IntentionOrderContract.productType = result1.get('productType')
    test_IntentionOrderContract.productName = result1.get('productName')
    test_IntentionOrderContract.rentId = result1.get('rentId')
    test_IntentionOrderContract.intentionId = result1.get('intentionId')
    test_IntentionOrderContract.earnestMoney = result1.get('earnestMoney')
    test_IntentionOrderContract.deptId = result1.get('deptId')
    test_IntentionOrderContract.test()

if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_Workflow10.py'])