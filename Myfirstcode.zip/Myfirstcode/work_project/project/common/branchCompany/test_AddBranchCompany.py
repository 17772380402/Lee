from project.utils.HttpMethod import *
from project.utils.DataUtils import *
from project.utils.data.branchCompanyData import *
import pytest

'''
新增分公司
'''

accountName = "测试分公司"
cityCode = "310100"
provinceCode = "310000"


def test():
    url = "/api/v1/webapp/bill/receive/band/v1/save/update"
    data = {
        "address": addr,
        "accountName": accountName,
        # "areaCode": areaCode,
        "areaName": areaName,
        "attachmentList": [
            {
                "name": "2020122100000036.jpg",
                "ossAttachUrl": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122100000036.jpg?Expires=1608534928&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=d4I24%2F6xtk3q9%2Bw%2FUtLObYuPdnI%3D",
                "type": "image/jpeg",
                "url": "http://maxima-file-staging.oss-cn-hangzhou.aliyuncs.com/2020122100000036.jpg?Expires=1608534928&OSSAccessKeyId=LTAIAdZ1VI4JWDPT&Signature=d4I24%2F6xtk3q9%2Bw%2FUtLObYuPdnI%3D",
            }
        ],
        "cityCode": cityCode,
        "cityName": "上海市",
        "companyStatus": 0,
        "corpId": 105338612,
        "email": email,
        "liaison": name,
        "liaisonPhone": mobile,
        "mobile": mobile,
        "provinceCode": provinceCode,
        "provinceName": "上海市",
        "receiveBankAccountAddDTOS": [
            {
                "accountType": 1,
                "bankName": bankName,
                "bankCard": bankCard
            }
        ],
        "registerNo": randomNum
    }
    return HttpMethod(url).post(data)


if __name__ == '__main__':
    pytest.main(['-s', '-v', 'test_AddBranchCompany.py'])
