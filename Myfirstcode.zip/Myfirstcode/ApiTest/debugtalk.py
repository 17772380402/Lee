import os
import random
import time
from random import randint
import redis  # 导入redis模块，通过python操作redis 也可以直接在redis主机的服务端操作缓存数据库
from faker import Faker
import datetime
import string

product_type = {
    "以租代购": "10901",
    "经营租赁": "10902",
    "分成租赁": "10903",
    "全款购车": "10904",
    "日租模式": "10905",
    "牌照租赁": "10906",
}


def get_contract_no():
    return int(time.time())


def range_string(lens=10):
    if lens > 62:
        lens = 62
    return ''.join(random.sample(string.ascii_letters + string.digits, lens))


def get_time(format_t='%Y-%m-%d', days=0, hours=0, minutes=0, seconds=0):
    return (datetime.datetime.now() + datetime.timedelta(days=days, hours=hours, minutes=minutes,
                                                         seconds=seconds)).strftime(format_t)


def activity_time(days=0):
    return get_time(days=days).replace('-', '')


def get_datetime(format_t='%Y-%m-%d %H:%M:%S', days=0, hours=0, minutes=0, seconds=0):
    return (datetime.datetime.now() + datetime.timedelta(days=days, hours=hours, minutes=minutes,
                                                         seconds=seconds)).strftime(format_t)


def reservation_start_time(days=1):
    return get_datetime(days=days)


def reservation_end_time(days=1):
    return get_datetime(days=days, hours=1)


def intention_date(days=0):
    return get_time(days=days)


def cut_int(numb, le):
    return int(numb + le)


city_productInfo = ([
    ["99674239", 55, 200, 319],
    ["99864216", 33, 53, 165]
])


def getDriverId(cityid="99674239"):
    i = 0
    for info in city_productInfo:
        temp = city_productInfo[i]
        if cityid == temp[0]:
            prod_rent = city_productInfo[i]
            break
        i = i + 1
    return prod_rent[1]


def getProductId(cityid="99674239"):
    i = 0
    for info in city_productInfo:
        temp = city_productInfo[i]
        if cityid == temp[0]:
            prod_rent = city_productInfo[i]
            break
        i = i + 1
    return prod_rent[2]


def get_product_id(city_id="99674239"):
    for info in city_productInfo:
        if info[0] == city_id:
            return info[2]


def getRentId(cityid="99674239"):
    i = 0
    for info in city_productInfo:
        temp = city_productInfo[i]
        if cityid == temp[0]:
            prod_rent = city_productInfo[i]
            break
        i = i + 1
    return prod_rent[3]


def connect_redis(func):
    redis_host = os.environ['RedisHost']
    password = os.environ['RedisPd']
    pool = redis.ConnectionPool(host=redis_host, password=password, port=6379,
                                decode_responses=True)  # host是redis主机，需要redis服务端和客户端都起着 redis默认端口是6379
    r = redis.Redis(connection_pool=pool)

    def __warp():
        return func(r)

    return __warp


@connect_redis
def get_web_token(c_redis):
    va = '''{"id":270,"tenantId":10000,"userCode":"250120076729262164","unionCode":"QiiI8Q89k3eBiSYCdhRYHFVAiEiE",
        "name":"王春明","tel":"","workPlace":"","mobile":"18818289089","email":"","orgEmail":"wangchunming@maxima-cars.com",
        "position":"后端研发工程师","avatar":"https://static.dingtalk.com/media/lADPDgQ9qmwXmX_NAoHNAoA_640_641.jpg",
        "hiredDate":"2019-04-10 00:00:00","jobNumber":"","roles":[2,4,10],"departments":[99781234,115100152]} '''

    c_redis.set('TOKEN_wangchunming2233', va)
    return 'wangchunming2233'


@connect_redis
def set_WxRedis(c_redis):
    va = '''{"openId":"oy3_N4sakKJAPeM3pNDzdQ9-mrhY","custId":51572,"custName":"尹环平","mobile":"15000519866"}'''
    token = range_string(lens=18)
    if c_redis.set('TOKEN_{}'.format(token), va, ex=3600 * 24):
        return token
    else:
        return 'set_token_error'


def round_model(model):
    pro = model[random.randint(0, len(model) - 1)]
    if pro.get('children'):
        code = round_model(pro['children'])
        return code
    else:
        code = pro['code']
        return code


def get_exit_programme(activity):
    return activity['modelId']


def get_mobile():
    return Faker(locale='zh_CN').phone_number()


def get_age():
    return random.randint(18, 80)


def get_city():
    return Faker(locale='zh_CN').city_suffix()


def get_level():
    level = [11501, 11502, 11503, 11504, 11505, 11506, None]
    return random.choice(level)


def get_level_desc(level_key):
    if level_key is None:
        return None
    level = {11501: 'A类', 11502: 'B类', 11503: 'C类', 11504: 'D类', 11505: 'E类', 11506: 'F类'}
    return level[level_key]


def get_name():
    return Faker(locale='zh_CN').name()


def get_ssn():
    return Faker(locale='zh_CN').ssn()


def get_gender():
    gender = ['男', '女']
    return random.choice(gender)


def get_job():
    return Faker().job()


def get_remark():
    return '{}'.format(Faker().profile())[:200]


def get_source():
    source = ['58投递', '滴滴名单', '转介绍', '其他', '58下载', '58微聊', '微信公众号', '今日头条', '58来电', '百姓网', '597人才网', '恒信人才网', '招聘狗',
              '温州人才网']
    return random.choice(source)


def transfer_type():
    trans_type = [11702, 11701]
    return random.choice(trans_type)


def get_range_number(digits):
    return Faker().random_number(digits=digits)


def set_list(value):
    list_set = list()
    list_set.append(value)
    return list_set


# 生成车牌号
def get_plate():
    license_plate_num = (
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
    )
    plate = "{0}{1}{2}".format(
        "自",
        "A",
        "".join(random.sample(license_plate_num, 5))
    )
    return plate


def get_vin_code():
    # 内容的权值
    content_map = {
        'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5,
        'F': 6, 'G': 7, 'H': 8, 'I': 0, 'J': 1, 'K': 2, 'L': 3,
        'M': 4, 'N': 5, 'O': 0, 'P': 7, 'Q': 8, 'R': 9, 'S': 2, 'T': 3,
        'U': 4, 'V': 5, 'W': 6, 'X': 7, 'Y': 8, 'Z': 9, "0": 0, "1": 1,
        "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9
    }
    # 位置的全值
    location_map = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
    vin = ''.join(random.sample('0123456789ABCDEFGHJKLMPRSTUVWXYZ', 17))
    num = 0
    for i in range(len(vin)):
        num = num + content_map[vin[i]] * location_map[i]
    vin9 = num % 11
    if vin9 == 10:
        vin9 = "X"
    list1 = list(vin)
    list1[8] = str(vin9)
    vin = ''.join(list1)
    return vin


def get_register_date(days=0):
    return get_time(days=days)


def get_valid_date(days=1):
    return get_time(days=days)


def get_engine_no():
    engine_no = randint(100000000, 999999999)
    return engine_no


# def get_model_id():
#     # return "29147"
#     return "27540"


def get_end_date(days=365):
    return get_time(days=days)


def get_insurance_no():
    insurance_no = randint(1000000000, 9999999999)
    return str(insurance_no)


def get_start_date(days=365):
    return get_time(days=days)


def get_contract_start_date(days=-30):
    return get_time(days=days)


def get_contract_end_date(days=335):
    return get_time(days=days)


def get_contract_no():
    contract_no = randint(1000000000, 9999999999)
    return "Z" + str(contract_no)


def get_user_agent():
    return Faker().user_agent()
# print("contract:" +get_ContractNO())
# print(activity_time(-1))
