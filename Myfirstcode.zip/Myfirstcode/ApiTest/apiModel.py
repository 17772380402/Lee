# coding:utf-8
import json
import requests
import os
import yaml

Urls = ['http://192.168.16.51:8003/v2/api-docs', 'http://192.168.16.51:8006/v2/api-docs']
api_model = []


def get_property(definitionss, obs):
    body_key = dict()
    properties = definitionss.get(obs)['properties']
    for pro in properties.keys():
        if properties[pro].get('items') and properties[pro].get('items').get('$ref'):
            obj = str(properties[pro].get('items').get('$ref')).replace('#/definitions/', '')
            link_to = get_property(definitionss, obj)
            body_key[pro] = link_to
            continue
        body_key[pro] = properties[pro]['type']
    return body_key


for url in Urls:
    res = requests.get(url)
    [os.makedirs('api_pool/{}'.format(i['name']), exist_ok=True) for i in res.json()['tags']]
    api_path = res.json()['paths']
    definitions = res.json()['definitions']

    for i in tuple(api_path.keys()):
        model = dict()
        value = api_path[i]
        method = tuple(value.keys())[0]
        model['url'] = i
        model['method'] = method
        model['file'] = '{0}/{1}.yml'.format(value[method]['tags'][0], value[method]['operationId'])
        model['name'] = value[method]['summary']
        params = value[method].get('parameters')
        path = dict()
        query = dict()
        body = dict()
        if params:
            for param in params:
                if param['in'] == 'query':
                    query[param['name']] = param['required']
                elif param['in'] == 'path':
                    path[param['name']] = param['required']
                elif param['in'] == 'body':
                    if not param.get('schema').get('$ref'):
                        body['param'] = param.get('schema')
                    else:
                        ob = str(param.get('schema').get('$ref')).replace('#/definitions/', '')
                        a = get_property(definitions, ob)
                        body[param['name']] = a

        model['request'] = {'path': path, 'query': query, 'body': body}
        api_model.append(model)


def get_template(file_path):
    with open(file_path, encoding='utf-8')as f:
        return yaml.load(f, Loader=yaml.FullLoader)


for i in api_model:
    template_api = get_template('template/api_template.yml')
    template_api['name'] = i['name']
    template_api['request']['url'] = i['url']
    template_api['request']['method'] = i['method']
    template_api['variables'] = i.get('request').get('path')
    template_api['request']['params'] = i.get('request').get('query')
    template_api['request']['json'] = i.get('request').get('body').get('param')
    file_path = 'api_pool/{}'.format(i['file'])
    with open(file=file_path, mode='w', encoding='utf-8') as f:
        yaml.dump(template_api, f, allow_unicode=True)
