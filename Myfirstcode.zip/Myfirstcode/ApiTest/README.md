### 安装python3 环境 版本3.7以上,并安装pipenv
```
➜ python3 --version
Python 3.7.3

➜ pip3 install pipenv
➜ pipenv --version
pipenv, version 2018.11.26

``` 
### 启用pipenv虚拟环境
`pipenv shell`
### 安装所有依赖
`pipenv install --dev`

### 执行case脚本
`pipenv run hrun ${case_path}`
### 指定运行环境 
`pipenv run hrun ${case_path} --dot-env-path ${DOT_ENV_PATH}`  
### 设置运行时log等级 
`pipenv run hrun ${case_path} --log-level ${LOG_LEVEL} ` 
### 自动生成api模版文件
`get_api_yml.py`
### 通过swagger 获取接口生成接口模版文件
`apiModel.py`