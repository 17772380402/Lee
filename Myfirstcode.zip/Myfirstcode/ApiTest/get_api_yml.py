import yaml

template_api = {
    'name': '',
    'variables': '',
    'request': {
        'url': '',
        'method': '',
        'headers': {
            'token': '',
            'User-Agent':
                ''
        },
        'params': '',
        'data': '',
        'json': ''
    },
    'validate': ''
}
template_test_case = [
    {
        'config': {
            'name': '',
            'base_url': '',
            'variables': [
                {'User-Agent': ''},
                {'token': ''}
            ],
            'output': '',
            'setup_hooks': '',
            'teardown_hooks': ''
        }
    },
    {
        'test': {
            'name': '',
            'api': '',
            'validate': '',
            'extract': '',
            'output': '',
            'setup_hooks': '',
            'teardown_hooks': ''
        }
    }
]
template_test_suite = {
    'config': {
        'name': '',
        'base_url': '',
        'variables': [
            {'User-Agent': ''},
            {'token': ''}
        ],
        'setup_hooks': [''],
        'teardown_hooks': ['']},
    'testcases': {
        'create user 1000 and check result.': {
            'testcase': '',
            'variables': '',
            'parameters': ''
        },
        'api': '',
        'validate': '',
        'extract': '',
        'setup_hooks': [''],
        'teardown_hooks': ['']
    }
}


def create_file(file_name=input('sed file name：'), number=int(input('sed template number:'))):
    global template
    if number == 1:
        template = template_api
        file_name = 'api/{}.yml'.format(file_name)
    elif number == 2:
        template = template_test_case
        file_name = 'testcases/{}.yml'.format(file_name)
    elif number == 3:
        template = template_test_suite
        file_name = 'testsuites/{}.yml'.format(file_name)
    with open(file=file_name, mode='w', encoding='utf-8') as f:
        yaml.dump(template, f, allow_unicode=True)


create_file()
