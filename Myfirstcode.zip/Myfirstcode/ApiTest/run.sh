#!/bin/bash
pipenv shell
pipenv install --dev
pipenv run hrun testcases/customer/customer.yml --log-level debug
#pipenv run hrun testsuites/smoking_test.yml --log-level debug
#pipenv run hrun testsuites/smoking_test.yml --log-level debug
exit